package com.example.tp4.Dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.example.tp4.Entity.Contact;

import java.util.List;

@Dao
public interface Contact_Dao {


    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void ajouterContact(Contact contact);

    @Update
    void mettreAjourContact(Contact contact);

    @Delete
    void suprimmerContact(Contact contact);

    @Query("select * from contact_table")
    LiveData<List<Contact>> getAllContact();


}
