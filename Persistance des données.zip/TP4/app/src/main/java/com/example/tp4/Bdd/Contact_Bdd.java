package com.example.tp4.Bdd;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.example.tp4.Dao.Contact_Dao;
import com.example.tp4.Entity.Contact;

@Database(entities = {Contact.class},version =1,exportSchema = false)
public abstract class Contact_Bdd extends RoomDatabase{

    //methode qui retourne des DAO
    public abstract Contact_Dao contactDao();

    private static Contact_Bdd INSTANCE;


    //Singleton
    public static Contact_Bdd getInstance(Context context){
        //verification de l'existance de l'instance
        if(INSTANCE ==null){
            synchronized (Contact_Bdd.class){
                //reverification
                if(INSTANCE==null){
                    //Creation BDD
                    INSTANCE = Room.databaseBuilder(context,Contact_Bdd.class, "baseContact").build();
                }
            }
        }
        return INSTANCE;

    }



}
