package com.example.tp4.Repository;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import com.example.tp4.Bdd.Contact_Bdd;
import com.example.tp4.Dao.Contact_Dao;
import com.example.tp4.Entity.Contact;

import java.util.List;
import java.util.concurrent.CompletableFuture;

public class Contact_Repository {

    //pour manipuler les donnees ( recuperer, ajouter, ...)
    Contact_Dao myDao;

    //en cas ou le viewModel souhaite recuperer le liste des contacts
    LiveData<List<Contact>> myList;

    //Constructeur
    //application non context (context c'est faut)
    public Contact_Repository(Application application){
        //recuperer bdd (application car le view model ne doit pas connaitre l'interface on est dans le MVVM)
        Contact_Bdd myBd = Contact_Bdd.getInstance(application);
        myDao=myBd.contactDao();
        myList= myDao.getAllContact();
    }

    public LiveData<List<Contact>> getMyList() {
        return myList;
    }

    //Ajout dans le repository
    public void ajouterContact(Contact contact){
        new InsertAsyncTask(myDao).execute(contact);
    }


    //l'execution des fcts qui sont dans le DAO demande un temps conciderable qui est independant de notre application.
    //Quand on envoi une requete a la bdd elle peut prendre du temps pour repondre indepandament de l'application
    //on cree un "thread" qui est un processus qui s'execute independament du processus principale
    // car si notre bdd prend beaucoup de temps pour s'executer on va etre figer (application qui bug jusqu'a l'arriver de la reponse)

    //le corps de processu
    // pour cree un thread on cree asynchcrone classe
    private class InsertAsyncTask extends AsyncTask<Contact,Void,Void>{

        Contact_Dao myDao;

        public InsertAsyncTask(Contact_Dao myDao) {
            this.myDao = myDao;
        }

        @Override
        protected Void doInBackground(Contact... contacts) {
            //insert
            myDao.ajouterContact(contacts[0]);
            return null;
        }
    }



    //update


    //delete
}
