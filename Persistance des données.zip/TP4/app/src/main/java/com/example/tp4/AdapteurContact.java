package com.example.tp4;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tp4.Entity.Contact;

import java.util.List;

public class AdapteurContact extends RecyclerView.Adapter<AdapteurContact.ContactViewHolder> {


    //creation context
    Context context;
    //La liste de contact qu'on va manipuler pour representer l'item
    List<Contact> mList;

    //Constructeur
    public AdapteurContact(Context context,List<Contact> mList) {
        this.context = context;
        this.mList=mList;
    }

    //Sont role: liéer le ContactViewHolder comme etant une classe avec le fichier XML item_contact
    @Override
    public AdapteurContact.ContactViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        //inflater relie le xml et java
        //R.layout.item_contact -> fichier XML a lier
        //parent -> le conteneur = recyclerView
        //false -> Ne pas attacher l'element = aller en bas on trouve different contact pas le meme -> recycler les view
        //Creation d'une vue
        View view =LayoutInflater.from(context).inflate(R.layout.item_contact,parent,false);
        return new ContactViewHolder(view);
    }

    //Sont role: liéer l'objet cree par la 1ere methode avec les donnees qui sont dans la liste
    //1er contact=1er item
    @Override
    public void onBindViewHolder(AdapteurContact.ContactViewHolder holder, int position) {

        //lier le ContactViewHolder avec les contacts dans la liste
        holder.nom.setText(mList.get(position).getNom());
        holder.tel.setText(mList.get(position).getTel());

    }
    public void setmList(List<Contact> mList) {
        this.mList = mList;

        //notification de l'interface
        notifyDataSetChanged();
    }


    //Le nombre d'item qu'on va afficher -> recupere de la liste qu'on va recuperer de la bdd
    @Override
    public int getItemCount() {
        if(mList!=null) return mList.size();
        return 0;
    }

    //Adapteur
    public class ContactViewHolder extends RecyclerView.ViewHolder {

        //manipuler les text view dans item contact
        TextView nom;
        TextView tel;

        public ContactViewHolder(View itemView) {
            super(itemView);
            nom = itemView.findViewById(R.id.tv_nom);
            tel = itemView.findViewById(R.id.tv_numero);
        }
    }
}
