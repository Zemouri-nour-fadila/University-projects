package com.example.tp4;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.tp4.Entity.Contact;
import com.example.tp4.ViewModel.Contact_ViewModel;

public class AddContactActivity extends AppCompatActivity {

    EditText nom;
    EditText numero;
    Button valider;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_contact);
        nom=findViewById(R.id.ed_nom);
        numero=findViewById(R.id.ed_numero);
        valider=findViewById(R.id.btn_valider);
        Contact_ViewModel contactViewModel=new ViewModelProvider(this).get(Contact_ViewModel.class);

        valider.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Contact c = new Contact();
                c.setNom(nom.getText().toString());
                c.setTel(numero.getText().toString());
                contactViewModel.ajouterContact(c);
                finish();
            }
        });
    }
}