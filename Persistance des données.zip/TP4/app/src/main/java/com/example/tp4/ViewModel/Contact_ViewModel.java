package com.example.tp4.ViewModel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.tp4.Entity.Contact;
import com.example.tp4.Repository.Contact_Repository;

import java.util.List;


// ViewModel vs AndroidViewModel
// View model ne peut pas utiliser le "context" qu'on utilise dans le repository pour cree la base
//On va cree une confusion si on appele repository ici
public class Contact_ViewModel extends AndroidViewModel{

    Contact_Repository mContactRepository;
    LiveData<List<Contact>> mListContact;


    //remove @NonNull
    public Contact_ViewModel(Application application) {
        super(application);
        mContactRepository = new Contact_Repository(application);
        mListContact = mContactRepository.getMyList();
    }

    //mettre a jour la liste
    public LiveData<List<Contact>> getMyListContact(){
        mListContact = mContactRepository.getMyList();
        return mListContact;

    }

    //Ajout contact
    public void ajouterContact(Contact contact){
        mContactRepository.ajouterContact(contact);
    }

    //Update
    /*public void updateContact(Contact contact){
        mContactRepository.updateContact(contact);
    }*/

    //Delete
    /*public void deleteContact(Contact contact){
        mContactRepository.deleteContact(contact);
    }*/
}
