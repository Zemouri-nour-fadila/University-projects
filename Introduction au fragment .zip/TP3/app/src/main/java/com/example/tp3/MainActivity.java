package com.example.tp3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText nom;
    EditText password;
    Button valider;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Creer une instance
        nom=findViewById(R.id.et_nom);
        password=findViewById(R.id.et_password);
        valider=findViewById(R.id.btn_valider);

        //ajouter un controleur pour le boutton valide
        valider.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String n = nom.getText().toString();
                String p = password.getText().toString();
                if(n.equals("admin")&&p.equals("admin")){
                    Toast.makeText(getApplicationContext(),"Bienvenu! Vous etes connecter",Toast.LENGTH_LONG).show();

                    //ajouter le fragment information
                    getSupportFragmentManager().beginTransaction().add(R.id.fragmentContainerView,InformationFragment.newInstance(n,null),null).commit();
                }else{
                    Toast.makeText(getApplicationContext(),"Information erronées!",Toast.LENGTH_LONG).show();

                    //ajouter le fragment recuppere votre mot de passe
                    getSupportFragmentManager().beginTransaction().add(R.id.fragmentContainerView,ErreurLoginFragment.class,null).commit();
                }
            }
        });
    }
}

