package Partie3;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import Structure.EnsembleClauses;
import Structure.Literale;

public class ACS {
	private int max_iter;
	private int nbr_fourmis;
	private double alpha;
	private double beta; 
	private double ro;// quantit�  initiale de pheromone
	private EnsembleClauses ec;
	private double[][] pheromone;// la table de pheromone
	private double q0;
	private double taux_evaporation;
	private ArrayList<Fourmis> EFBest = new ArrayList<Fourmis>();
	private int Max_fourmis;
	private long mili;
	private long mem_utilise_acs ;
                   
	public ACS(int max_iter, int nbr_fourmis, double alpha, double beta, EnsembleClauses ec, double taux_evaporation,double q0,double ro)
			throws InterruptedException {
		super();
		this.max_iter = max_iter;
		this.nbr_fourmis = nbr_fourmis;
		this.alpha = alpha;
		this.beta = beta;
		this.ec = ec;
		this.taux_evaporation = taux_evaporation;
		this.q0 = q0;
		this.ro=ro;
	}

	public String Execution_ACS() throws InterruptedException {
		Runtime rt = Runtime.getRuntime(); 
		java.util.Date Debut_execution = new java.util.Date (System.currentTimeMillis ()); 
		//Relever l'heure avant le debut du progamme (en milliseconde)
       //ensembles des solution d'une generation
       //---------------------------------------
		ArrayList<Fourmis> EF = new ArrayList<Fourmis>();
       //initialisation de la table de pheromone 
       //----------------------------------------
		pheromone = Intialisation();
		Fourmis fourmis = new Fourmis();
		for (int i = 0; i < max_iter; i++) {
			for (int j = 0; j < nbr_fourmis; j++) {
				fourmis = new Fourmis();
				//list_lit :solution construite par la fourmis 
				ArrayList<Literale> liste_Lit = new ArrayList<Literale>();
				//initialisation de l'etat initial de la fourmis aleatoirement
				Random random = new Random();
				int Num = random.nextInt(ec.getNombreLiteraux());//la val generer entre  0 et 74
				Num = Num + 1;
				int val = random.nextInt(2);//0 ou 1
				Literale l = new Literale(Num, val);

				Fourmis Solution = new Fourmis(); 
				liste_Lit.add(l);
				Solution.setListe_Lit(liste_Lit);

				/**1/construction**/
				liste_Lit =fourmis.Construction_Solution(Solution.getListe_Lit(),ec, pheromone,q0,alpha,beta);
				fourmis.setListe_Lit(liste_Lit);

				/**2/Evaluation**/
				int f = ec.Nombre_Clauses_SAT(fourmis);
				fourmis.setFitness(f);

				/**3/mise a jour en ligne**/
				fourmis.Update_enligne(ec,pheromone,taux_evaporation,ro);

				/**4/Insertion**/
				EF.add(fourmis);

			}//Fin boucle fourmis

			// On Selectionne la meilleure solution pandant cette generation
			EF.sort(Collections.reverseOrder());
			// ins rer la meilleur solution g n r  dans la g n ration dans EFBest
			EFBest.add(EF.get(0)); 
		
             /**5/mise a jour offline**/
 
			Fourmis so=EF.get(0);
			so.Update_Offline(pheromone,taux_evaporation);
			EF = new ArrayList<Fourmis>();
		}//fin boucle maxitter
 

		EFBest.sort(Collections.reverseOrder());
		Date FIN_exection = new Date (System.currentTimeMillis()); //Relever l'heure a la fin du progamme (en milliseconde) 
		Date duree = new Date (System.currentTimeMillis()); //Pour calculer la diff rence
		duree.setTime (FIN_exection.getTime () - Debut_execution.getTime ());  //Calcul de la diff rence
		 mili = duree.getTime () % 1000;
         //Complexite spatielle 
			 //-------------------
			 long mem_total = rt.totalMemory(); 
			 long mem_libre = rt.freeMemory(); 
			// Le resultat obtenu sera en octet (byte) on le rend en Mega octet
			//-----------------------------------------------------------------
			     mem_utilise_acs = ((mem_total - mem_libre)/1024)/1024 ;
		Max_fourmis=EFBest.get(0).getFitness();
		return EFBest.get(0).toString();
	}
// ________________________________________________________________________________
// |                                                                              |
// | Intialisation : Initialisation de la pheromone                               |
// |______________________________________________________________________________|
// 
	public double[][] Intialisation() {
		// initialisation de la table de pheromone
		// ----------------------------------------
		this.pheromone = new double[ec.getNombreLiteraux()][2];
		for (int i = 0; i < pheromone.length; i++) {
			for (int j = 0; j < pheromone[0].length; j++) {
				pheromone[i][j] = ro;				
			}
		}
		return pheromone;
	}
/******************************  LES GETTERS el LES SETTERS ***********************************/
                               /****************************/
	public EnsembleClauses getEc() {
		return ec;
	}
	public void setEc(EnsembleClauses ec) {
		this.ec = ec;
	}
	public int getMax_iter() {
		return max_iter;
	}
	public void setMax_iter(int max_iter) {
		this.max_iter = max_iter;
	}
	public int getNbr_fourmis() {
		return nbr_fourmis;
	}
	public void setNbr_fourmis(int nbr_fourmis) {
		this.nbr_fourmis = nbr_fourmis;
	}
	public double getAlpha() {
		return alpha;
	}
	public void setAlpha(double alpha) {
		this.alpha = alpha;
	}

	public double getBeta() {
		return beta;
	}
	public void setBeta(double beta) {
		this.beta = beta;
	}
	public double getRo() {
		return ro;
	}
	public void setRo(double ro) {
		this.ro = ro;
	}
	public double[][] getPheromone() {
		return pheromone;
	}
	public void setPheromone(double[][] pheromone) {
		this.pheromone = pheromone;
	}
	public double getQ0() {
		return q0;
	}
	public void setQ0(double q0) {
		this.q0 = q0;
	}
	public double getTaux_evaporation() {
		return taux_evaporation;
	}
	public void setTaux_evaporation(double taux_evaporation) {
		this.taux_evaporation = taux_evaporation;
	}
	public int get_fitness() {
		return Max_fourmis;
	}
	public long get_tmp_acs() {
		return mili;
	}
	public long get_sp_acs() {
		return  mem_utilise_acs ;
	}
}
