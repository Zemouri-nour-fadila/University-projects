package Partie3;

import Structure.Literale;

public class Literale_acs extends Literale implements Comparable<Literale_acs> {
	// d�claration des variables
	// -------------------------
	private float Probaba_Transition;

	public  Literale_acs() {
		super();
	}  
	public Literale_acs(int numero, int valeur) {
		super(numero, valeur);
	}
/******************************  LES GETTERS el LES SETTERS ***********************************/
                               /****************************/
	public float getProbaba_Transition() {
		return Probaba_Transition;
	}

	public void setProbaba_Transition(float Probaba_Transition) {
		this.Probaba_Transition = Probaba_Transition;
	}	
//  __________________________________________________________________________	 
// |                                                                          |
// | compareTo :Comparer les litteraux                                        | 
// |__________________________________________________________________________|
	@Override
	public int compareTo(Literale_acs L) {
		if (this.Probaba_Transition > L.Probaba_Transition) return 1;
		if (this.Probaba_Transition < L.Probaba_Transition) return -1;
		return 0;
	}
	
	@Override
	public String toString() {

		return "Literale_acs{" +
				"numero=" + getnumero() +
				", valeur=" + getvaleur() +
				", Etat=" + getEtat() +
				", Probaba_Transition=" + Probaba_Transition +
				'}';
	}
}
