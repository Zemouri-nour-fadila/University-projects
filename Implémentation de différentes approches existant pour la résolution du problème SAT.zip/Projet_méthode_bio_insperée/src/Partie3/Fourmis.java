package Partie3;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import Structure.EnsembleClauses;
import Structure.Literale;
import Structure.Noeud;

public class Fourmis implements Comparable<Fourmis> {

	private ArrayList<Literale> list_lit = new ArrayList<Literale>();
	private int Fitness;

	HashMap<Integer,Literale_acs> liste_Lit_non_instancier = new HashMap<Integer, Literale_acs>();
	ArrayList<Literale_acs> Noued_prob = new ArrayList<Literale_acs>();
	Fourmis() {}
	public Fourmis(Fourmis s) {
		this.list_lit = s.list_lit; 
		this.Fitness = s.Fitness;
	}
	public ArrayList<Literale> Construction_Solution(ArrayList<Literale> liste_Lite_instancier, EnsembleClauses ec, double[][] pheromone, double q0, double alpha, double beta) throws InterruptedException {

		for (int i = 0; i < ec.getNombreLiteraux(); i++) {
			Literale tmp = ec.getList_Litteral().get(i);
//Liste non instancier contient  literal avec les 2 instanciation 
//------------------------------------------------------------------
			if (!Exist(liste_Lite_instancier, ec.getList_Litteral().get(i))) {
				liste_Lit_non_instancier.put(
					-tmp.getnumero(),
					new Literale_acs(tmp.getnumero(),0)//(Key,valeur)
				);
				// pour r cup rer literale avec instanciation 1
				liste_Lit_non_instancier.put(
					tmp.getnumero(),
					new Literale_acs(tmp.getnumero(), 1)
				);
			}
		}

		list_lit = Regle_transition(liste_Lit_non_instancier, ec, pheromone, q0, alpha, beta);

		return list_lit;
	}

//___________________________________________________________________________________
//|                                                                                   |
//| Exist :verifier si un litteral existe dans la liste des litt raux instancier      | 
//|___________________________________________________________________________________|

	private static boolean Exist(ArrayList<Literale> i, Literale literal) {
		for (Literale l : i) {
			if (literal.getnumero() == l.getnumero())
				return true;
		}
		return false;
	}
//__________________________________________________________________________________	 
//|                                                                                 |
//| regle_transition : Selection des lits en se basant sur la regle de transition   | 
//|_________________________________________________________________________________|

private ArrayList<Literale> Regle_transition(HashMap<Integer,Literale_acs> liste_Lit_Non_instancier,EnsembleClauses ec,double [][] pheromone,double q0,double alpha,double beta)
		throws InterruptedException {
	Noeud root = new Noeud();
	Noeud SAT = root;
	ArrayList<Literale> liste_ACS = new ArrayList<Literale>();
	

	while (liste_Lit_Non_instancier.size() > 0) {

		Literale_acs tmp ;
		float somme  = Vecteur_Probability(liste_Lit_Non_instancier, ec,pheromone, alpha, beta,Noued_prob);
		int k = 0;

/*****Regle de transition***/
//---------------------------
		Random r = new Random();
		double q = r.nextDouble();

		if (q <= q0) {
			Noued_prob.sort(Collections.reverseOrder());
			tmp=Noued_prob.get(0);
		} else {
			/*****Selection par roulette***/

			Random r2 = new Random();
			double nbr_aleatoire = (double) r2.nextDouble();// >0
			Collections.sort(Noued_prob);
			for (int o = 0; o < Noued_prob.size()-1; o++) {
				double borne_sup1 = Math.abs( Noued_prob.get(o).getProbaba_Transition()/somme);
				if (nbr_aleatoire < borne_sup1){//[0,Noued_prob(0)]
					k = o;
					break;
				}else {
					double borne_sup2 = Math.abs((Noued_prob.get(o).getProbaba_Transition()+Noued_prob.get(o+1).getProbaba_Transition())/ somme);
					if(nbr_aleatoire < borne_sup2){//[proba(0),priba(0)+proba(1)]
						k = o+1;
						break;
					}
				}
			}
			tmp = Noued_prob.get(k);
		}

		liste_ACS.add(tmp);
		liste_Lit_Non_instancier.remove(tmp.getnumero());
		liste_Lit_Non_instancier.remove(tmp.getnumero()*-1);

	}
	return liste_ACS;
}
/****************************** Traitement ***********************************/
                               /************/

//____________________________________________________________________________
//|                                                                            |
//| Calcule_Probability : Calculer la probabilit  de l'etat (literal)          | 
//|____________________________________________________________________________|

	private float Calcule_Probability(Literale Literal_selected, int f, double[][] pheromone, double alpha,double beta) {

		float Probability = (float) (Math.pow(pheromone[Literal_selected.getnumero() - 1][Literal_selected.getvaleur()],
				alpha) * Math.pow(f, beta));
		return Probability;
	}
//________________________________________________________________________________
//|                                                                               |
//| METHODE 1 :Update_enligne : Mettre   jours la pheromone                       |
//|_______________________________________________________________________________|

	public void Update_enligne(EnsembleClauses ec, double[][] pheromone, double taux_evaporation, double ro) {
		// mise a jour en ligne de la pheromone de la fourmis actuelle
		// -------------------------------------------------------------
		for (int l = 0; l < this.getListe_Lit().size(); l++) {
			int column = this.getListe_Lit().get(l).getvaleur();
			int ligne = this.getListe_Lit().get(l).getnumero() - 1;
			pheromone[ligne][column] = ((1 - taux_evaporation) * pheromone[ligne][column]) + (taux_evaporation * ro);
		}
	}
// ________________________________________________________________________________
// |                                                                               |
// | METHODE 2 :Update_Offline : Mettre   jours la pheromone                       |
// |_______________________________________________________________________________|

	public void Update_Offline(double[][] pheromone, double taux_evaporation) {
		// TODO Auto-generated method stub
		// mise a jour en ligne de la pheromone de la fourmis actuelle
		// -------------------------------------------------------------
		for (int l = 0; l < this.getListe_Lit().size(); l++) {
			int column = this.getListe_Lit().get(l).getvaleur();
			int ligne = this.getListe_Lit().get(l).getnumero() - 1;
			int best_cout = this.getFitness();
			pheromone[ligne][column] = ((1 - taux_evaporation) * pheromone[ligne][column])
					+ (taux_evaporation * best_cout);
		}
	}

	public Float Vecteur_Probability(HashMap<Integer, Literale_acs> Liste_non_instancier, EnsembleClauses ec,
			double[][] pheromone, double alpha, double beta, ArrayList<Literale_acs> Noued_prob)
			throws InterruptedException {

		float somme = 0;
		// Percourir la liste non instancier
		// ----------------------------------
		Literale_acs lit;

		Noued_prob.clear();
		for (Map.Entry<Integer, Literale_acs> entry : Liste_non_instancier.entrySet()) {
			lit = entry.getValue();// r cup rer literale

			int fitness = ec.Nombre_Clauses_SAT(lit);
			float P = Calcule_Probability(lit, fitness, pheromone, alpha, beta);

			// 6-Associer la probabilit  au noeud
			// ---------------------------------
			lit.setProbaba_Transition(P);
			Noued_prob.add(lit);
			somme += P;
		}

		return somme;
	}


/******************************  LES GETTERS el LES SETTERS ***********************************/
                               /****************************/

	public ArrayList<Literale> getListe_Lit() {
		return list_lit;
	}
	public int getFitness() {
		return Fitness;
	}
	public void setListe_Lit(ArrayList<Literale> liste_Lit) {
		this.list_lit = liste_Lit;
	}

	public void setFitness(int f) {
		this.Fitness = f;
	}

/******************************  Methodes*******************************************************/
                               /*********/

	public String toString() {
		String SAT_solution = "";
		for (Literale l : list_lit)
			SAT_solution += l.getnumero() + "=" + l.getvaleur() + " ";
		return "la solution trouv�e {"+SAT_solution+"}";
	}

	@Override
	public int compareTo(Fourmis o) {
		if (this.Fitness > o.Fitness) return 1; 
		if (this.Fitness < o.Fitness) return -1;

		return 0;
	}
}