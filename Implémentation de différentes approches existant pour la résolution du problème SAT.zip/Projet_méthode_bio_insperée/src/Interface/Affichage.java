package Interface;

import java.awt.Font;
import java.awt.Panel;
import java.awt.SystemColor;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class Affichage extends JFrame {
	JTabbedPane tabbedPane;
	Modele M;
	JTable table;
	JTable table2;
	JTable table3;
	 Panel DFS ;
	 Panel A_etoile ;
	 Panel GA;
	 Panel ACS;
	 private JLabel btn_exit;
	 private JLabel lblNewLabel;
	 JTable table4;
	 
	  public Affichage(){
		     getContentPane().setBackground(SystemColor.info);
		     getContentPane().setLayout(null);
		     
		     tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		     tabbedPane.setBounds(10, 36, 578, 377);
		     getContentPane().add(tabbedPane);
		     
		     A_etoile = new Panel();
		     A_etoile.setBounds(10, 36, 578, 376);
		     tabbedPane.addTab("A_etoile", null, A_etoile, null);
		     
		     DFS = new Panel();
		     DFS.setBounds(10, 36, 578, 376);
		     tabbedPane.addTab("DFS", null, DFS, null);
		     
		     GA = new Panel();
		     
		     tabbedPane.addTab("GA", null, GA, null);
		     
		     ACS = new Panel();
		     tabbedPane.addTab("ACS", null, ACS, null);

		     btn_exit = new JLabel("");
		     btn_exit.setIcon(new ImageIcon(Affichage.class.getResource("/Image/5735775.png")));
		     btn_exit.setBounds(541, 11, 37, 41);
		     btn_exit.addMouseListener(new MouseAdapter() {
		    		@Override
		    		public void mouseClicked(MouseEvent arg0) {
		    			dispose();
		    		}
		     });
		     getContentPane().add(btn_exit);
		    setUndecorated(true);
		    this.setLocationRelativeTo(null);
		    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		    this.setTitle("Affichage DFS");
		    this.setSize(600, 441);
		    this.setLocationRelativeTo(null);
		    this.DFS.add(new JScrollPane(table));
		    
		    lblNewLabel = new JLabel("Rapport");
		    lblNewLabel.setFont(new Font("Yu Gothic", Font.BOLD | Font.ITALIC, 25));
		    lblNewLabel.setBounds(251, 11, 118, 38);
		    getContentPane().add(lblNewLabel);
		    
		    JLabel lblNewLabel_1 = new JLabel("");
		    lblNewLabel_1.setIcon(new ImageIcon(Affichage.class.getResource("/Image/clipboard (1).png")));
		    lblNewLabel_1.setBounds(211, 0, 30, 52);
		    getContentPane().add(lblNewLabel_1);
	  }
	  public void Affichage(ArrayList<Modele> MODELES,int n ){
		   

	    //Les titres des colonnes
		  //--------------------
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Fichier");
        model.addColumn("Seuil");
        model.addColumn("Clause SAT");
        model.addColumn("Temps(ms)");
        model.addColumn("Espace(MO)");
        model.addColumn("Taux %");

	    for (int i=0 ;i<MODELES.size();i++) {
	    	long t1 = MODELES.get(i).sat;
	    	long taux=(t1*100)/n;
	    	model.addRow(new Object[]{MODELES.get(i).p,MODELES.get(i).s,MODELES.get(i).sat ,MODELES.get(i).tmp,MODELES.get(i).sp,taux});
	    }
	
         table = new JTable(model);
         table.setBounds(10, 36, 1000, 3513);
         JScrollPane scrollPane = new JScrollPane(table);
	    this.DFS.add(scrollPane);
	  
    
	  } 
	  
	  
	  public void Affichage2(ArrayList<Modele> MODELES,int n){
		    //Les titres des colonnes
			  //--------------------
	        DefaultTableModel model2 = new DefaultTableModel();
	        model2.addColumn("Fichier");
	        model2.addColumn("Clause SAT");
	        model2.addColumn("Temps(ms)");
	        model2.addColumn("Espace(MO)");
	        model2.addColumn("Taux %");
		   
		    for (int i=0 ;i<MODELES.size();i++) {
		    	long t1 = MODELES.get(i).sat;
		    	long taux=(t1*100)/n;
		    	model2.addRow(new Object[]{MODELES.get(i).p ,MODELES.get(i).sat ,MODELES.get(i).tmp,MODELES.get(i).sp,taux});
		    }
		
		    table2 = new JTable(model2);
		    table2.setBounds(10, 36, 1000, 3513);
		    //Nous ajoutons notre tableau à notre contentPane dans un scroll
		    //Sinon les titres des colonnes ne s'afficheront pas !
		    JScrollPane scrollPane2 = new JScrollPane(table2);
		    this.A_etoile.add(scrollPane2);
		    
		  
	    
		  } 
	  
	  public void Affichage3(ArrayList<Modele> MODELES,int n){
		    //Les titres des colonnes
			  //--------------------
	        DefaultTableModel model3 = new DefaultTableModel();
	        model3.addColumn("Fichier");
	        model3.addColumn("Max_iter");
	        model3.addColumn("P_croisement");
	        model3.addColumn("Taille pop");
	        model3.addColumn("P_mutation");
	        model3.addColumn("K-point");
	        model3.addColumn("Clause SAT");
	        model3.addColumn("Temps(ms)");
	        model3.addColumn("Espace(MO)");
	        model3.addColumn("Taux %");
		   
		    for (int i=0 ;i<MODELES.size();i++) {
		    	long t1 = MODELES.get(i).sat;
		    	long taux=(t1*100)/n;
		    	model3.addRow(new Object[]{MODELES.get(i).p,MODELES.get(i).iter,MODELES.get(i).pc,MODELES.get(i).tp,MODELES.get(i).pm,MODELES.get(i).kp,MODELES.get(i).sat ,MODELES.get(i).tmp,MODELES.get(i).sp,taux});
		    }
		
		    table3 = new JTable(model3);
		    table3.setBounds(10, 36, 1000, 3513);
		    //Nous ajoutons notre tableau à notre contentPane dans un scroll
		    //Sinon les titres des colonnes ne s'afficheront pas !
		    JScrollPane scrollPane3 = new JScrollPane(table3);
		    this.GA.add(scrollPane3);
		  
	    
		  } 
	  public void Affichage4(ArrayList<Modele> MODELES,int n){
		    //Les titres des colonnes
			  //--------------------
	        DefaultTableModel model4 = new DefaultTableModel();
	        model4.addColumn("Fichier");
	        model4.addColumn("Max_iter");
	        model4.addColumn("Nbr_fourmis");
	        model4.addColumn("α");
	        model4.addColumn("β");
	        model4.addColumn("𝛕");
	        model4.addColumn("q0");
	        model4.addColumn("ro");
	        model4.addColumn("Clause SAT");
	        model4.addColumn("Temps(ms)");
	        model4.addColumn("Espace(MO)");
	        model4.addColumn("Taux %");


		   System.out.print(MODELES.size());
		    for (int i=0 ;i<MODELES.size();i++) {
		    	long t1 = MODELES.get(i).sat;
		    	long taux=(t1*100)/n;
		    	model4.addRow(new Object[]{MODELES.get(i).p,MODELES.get(i).max_itetr,MODELES.get(i).nbr_F,MODELES.get(i).Alpha ,MODELES.get(i).Beta ,MODELES.get(i).Taux ,MODELES.get(i).q0 ,MODELES.get(i).ro, MODELES.get(i).sat ,MODELES.get(i).tmp,MODELES.get(i).sp,taux});
		    }
		
		    table4 = new JTable(model4);
		    table4.setBounds(10, 36, 1000, 3513);
		    //Nous ajoutons notre tableau à notre contentPane dans un scroll
		    //Sinon les titres des colonnes ne s'afficheront pas !
		    JScrollPane scrollPane4 = new JScrollPane(table4);
		    this.ACS.add(scrollPane4);
		  
	    
		  }
	  
public JTable get_table() {
	return table;
}
}
