package Interface;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Label;
import java.awt.Panel;
import java.awt.SystemColor;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.regex.Pattern;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.MatteBorder;
import javax.swing.border.TitledBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

import Partie1.A_etoile;
import Partie1.Recherche_Profondeur;
import Partie2.Recherche_GA;
import Partie3.ACS;
import Structure.EnsembleClauses;

public class Interface_BIO extends JFrame {
	private JFrame frmbioinspere;
	private JPanel contentPane;
	private JPanel panel_3;
	private JPanel panel_5;
	private JTextField URL_fichier;
	public String Chemin;
	int click =0 ;
	int n ;
	int val;
	long val2;
	long val3;
	int val6;
	long val4;
	long val5;
	String path ;
	EnsembleClauses EC;
	int SATG;
	long MILI;
	long ESPACE ;
	int sat_acs;
	long tmp_acs;
	long sp_acs;
	Affichage fenetre = new Affichage();
	public ArrayList<Modele>  MODELES=new ArrayList<Modele>();
	public ArrayList<Modele>  MODELES_A=new ArrayList<Modele>();
	public ArrayList<Modele>  MODELES_GA=new ArrayList<Modele>();
	public ArrayList<Modele>  MODELES_ACS=new ArrayList<Modele>();
	public JFrame getFrmBioInsp() {
		return frmbioinspere;
	}


//Changer la visibilité de l'interface
	public void setFrmBioInsp(JFrame BIO) {
		this.frmbioinspere = BIO;
	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Interface_BIO window = new Interface_BIO();
					window.frmbioinspere.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Interface_BIO() {
		initialize();
	}

	private void initialize() {
		frmbioinspere = new JFrame();
		frmbioinspere.setUndecorated(true);
		frmbioinspere.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmbioinspere.setBounds(100, 100, 734, 416);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		frmbioinspere.setContentPane(contentPane);
		contentPane.setLayout(null);
		frmbioinspere.setLocationRelativeTo(null);
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 102, 153));
		panel.setBounds(0, 0, 734, 415);
		contentPane.add(panel);
		panel.setLayout(null);

		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(10, 70, 720, 304);
		panel.add(tabbedPane);

		panel_3 = new JPanel();
		panel_3.setFont(new Font("Tahoma", Font.PLAIN, 12));
		panel_3.setBackground(new Color(51, 102, 153));
		tabbedPane.addTab("Validation", null, panel_3, null);
		tabbedPane.setForegroundAt(0, new Color(0, 102, 153));
		panel_3.setLayout(null);

		JPanel panel_4 = new JPanel();
		panel_4.setBorder(new LineBorder(new Color(51, 102, 153), 1, true));
		panel_4.setBounds(140, 60, 561, 103);
		panel_3.add(panel_4);
		
		JLabel lbl_nbr_clause = new JLabel("");
		lbl_nbr_clause.setForeground(Color.WHITE);
		lbl_nbr_clause.setBounds(420, 203, 46, 14);
		panel_3.add(lbl_nbr_clause);
		
		JLabel lbl_nbr_Lit = new JLabel("");
		lbl_nbr_Lit.setForeground(Color.WHITE);
		lbl_nbr_Lit.setBounds(420, 228, 46, 22);
		panel_3.add(lbl_nbr_Lit);
		panel_4.setLayout(null);
		
		
		panel_5 = new JPanel();
		panel_5.setBounds(10, 26, 541, 46);
		panel_5.setBorder(new LineBorder(new Color(51, 102, 153)));
		panel_5.setBackground(new Color(204, 204, 204));
		panel_4.add(panel_5);
		panel_5.setLayout(null);

		URL_fichier = new JTextField();
		URL_fichier.setForeground(new Color(51, 102, 153));
		URL_fichier.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 11));
		URL_fichier.setBounds(74, 10, 311, 23);
		panel_5.add(URL_fichier);
		URL_fichier.setColumns(10);

		JButton btn_selectionner = new JButton("S\u00E9lectionner");
		btn_selectionner.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 11));
		btn_selectionner.setForeground(new Color(0, 102, 153));
		btn_selectionner.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				// choisir un fichier :
				// ********************
				JFileChooser fichier_CNF = new JFileChooser();

				// extension cnf seulement :
				// *************************
				FileNameExtensionFilter cnf_filter = new FileNameExtensionFilter("cnf files (*.cnf)", "cnf");

				// Titre de la boite :
				// *******************
				fichier_CNF.setDialogTitle("choix du fichier");

				// set selected filter :
				// **********************
				fichier_CNF.setFileFilter(cnf_filter);

				// affichage :
				// ************
				int returnVal = fichier_CNF.showOpenDialog(null);
				// test pour dire qu'on a cliker sur ouvrir sinon annulé :
				// ********************************************************
				if (returnVal == JFileChooser.APPROVE_OPTION) {

					// on peut selectionner juste un seul fichier :
					// ******************************************** 
					fichier_CNF.setMultiSelectionEnabled(false);

					// On récupére le fichier sélectionné :
					// *************************************
					Chemin = fichier_CNF.getSelectedFile().getAbsolutePath();
					this.textFieldXML(Chemin);

				}

			}

			// Remplir le textField du URL_fichier :
			// **************************************
			private void textFieldXML(String chemin) {

				URL_fichier.setText(chemin);
			}
		});
		
//button selectionner 
//-------------------
		btn_selectionner.setBounds(395, 10, 109, 23);
		panel_5.add(btn_selectionner);

//Label Fichier :
//---------------
		JLabel lblFichier = new JLabel("Fichier :");
		lblFichier.setForeground(new Color(0, 102, 153));
		lblFichier.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lblFichier.setBounds(10, 12, 68, 19);
		panel_5.add(lblFichier);
		
		JLabel lblNombreDeClauses = new JLabel("Nombre de clauses   :");
		lblNombreDeClauses.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 13));
		lblNombreDeClauses.setForeground(new Color(255, 255, 255));
		lblNombreDeClauses.setBounds(283, 193, 145, 31);
		panel_3.add(lblNombreDeClauses);
		
		JLabel Label_nbr_Lit = new JLabel("Nombre de litt\u00E9raux :");
		Label_nbr_Lit.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 13));
		Label_nbr_Lit.setForeground(new Color(255, 255, 255));
		Label_nbr_Lit.setBounds(283, 228, 145, 22);
		panel_3.add(Label_nbr_Lit);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon(Interface_BIO.class.getResource("/Image/folder.png")));
		lblNewLabel_1.setBounds(-28, 11, 275, 230);
		panel_3.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setBounds(10, 193, 275, 31);
		panel_3.add(lblNewLabel_2);
		lblNewLabel_2.setIcon(new ImageIcon(Interface_BIO.class.getResource("/Image/info.png")));
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setIcon(new ImageIcon(Interface_BIO.class.getResource("/Image/info.png")));
		lblNewLabel_3.setBounds(10, 227, 345, 23);
		panel_3.add(lblNewLabel_3);
		
//btn_valider
//-------------------------------------------------------------------------------------------------------------------------
		JButton btn_valider = new JButton("Valider");
		btn_valider.setBounds(336, 169, 139, 23);
		panel_3.add(btn_valider);
		btn_valider.setForeground(new Color(0, 102, 153));
		btn_valider.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 13));
		btn_valider.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				//si on a cliker sur le butn valider 
				//*************************************
							 
				 //si le fichier.cnf est vide  on affiche un warning 
				 //**************************************************
				                if(URL_fichier.getText().equals(""))
				                {
				                    JOptionPane.showMessageDialog(null,"Le chemin du fichier à traiter n'est pas correcte !","ERREUR ",JOptionPane.ERROR_MESSAGE);
				                    return;
				                }else {
				                	
				  //Véréfication du chemin valide ou pas  
				  //************************************	
			/***Remarque**********************************************************************************************************************************/	                	
			//méthode exists(), qui vérifie l'existence d'un fichier 
			/********************************************************************************************************************************************/	                	
				                	
				                	
				                	File file = new File(URL_fichier.getText());
				                	if(file.exists() ) { 
				                		//Chemin correcte
				                	}else {
				                	JOptionPane.showMessageDialog(null," Le chemin du fichier à traiter n'est pas correcte , veuillez le corriger SVP !","ERREUR",JOptionPane.ERROR_MESSAGE);
				                	
				                	}
				                }
			             path=URL_fichier.getText();
						 EC=new EnsembleClauses(path);
						 n=EC.getNombreClause();
						lbl_nbr_clause.setText(String.valueOf(n));
						int m=EC.getNombreLiteraux();
						lbl_nbr_Lit.setText(String.valueOf(m));
						click=1;
						
						}
		});

		JPanel MAXITER = new JPanel();
		MAXITER.setForeground(new Color(0, 102, 153));
		MAXITER.setBackground(new Color(51, 102, 153));
		tabbedPane.addTab("Traitement", null, MAXITER, null);
		tabbedPane.setForegroundAt(1, new Color(0, 102, 153));
		MAXITER.setLayout(null);
//btn_A_etoile----------------------------------------------------------------------------------------------------------------------
		JButton btn_A_etoile = new JButton("A*");
		btn_A_etoile.setBounds(12, 33, 65, 23);
		btn_A_etoile.setFont(new Font("Times New Roman", Font.BOLD, 17));
		btn_A_etoile.setForeground(new Color(0, 102, 153));
		MAXITER.add(btn_A_etoile);
//btn_DFS-----------------------------------------------------------------------------------------------------------------------
		JButton btn_DFS = new JButton("DFS");
		btn_DFS.setBounds(75, 33, 71, 23);
		btn_DFS.setForeground(new Color(0, 102, 153));
		btn_DFS.setFont(new Font("Times New Roman", Font.BOLD, 17));
		MAXITER.add(btn_DFS);
//btn_GA-----------------------------------------------------------------------------------------------------------------------
		JButton btn_GA = new JButton("GA");
		btn_GA.setBounds(144, 33, 71, 23);
		btn_GA.setForeground(new Color(0, 102, 153));
		btn_GA.setFont(new Font("Times New Roman", Font.BOLD, 17));
		MAXITER.add(btn_GA);
//btn_ACS-----------------------------------------------------------------------------------------------------------------------

		JButton btn_ACS = new JButton("ACS");
		btn_ACS.setBounds(214, 33, 71, 23);
		btn_ACS.setForeground(new Color(0, 102, 153));
		btn_ACS.setFont(new Font("Times New Roman", Font.BOLD, 17));
		MAXITER.add(btn_ACS);
		
		Panel panel_2 = new Panel();
		panel_2.setBackground(new Color(220, 220, 220));
		panel_2.setBounds(12, 56, 395, 79);
		MAXITER.add(panel_2);
		panel_2.setLayout(null);
		
		Label label = new Label("Temps d'execution");
		label.setAlignment(Label.CENTER);
		label.setBackground(SystemColor.info);
		label.setBounds(278, 0, 117, 22);
		panel_2.add(label);
		
		Label label_1 = new Label("Espace m\u00E9moire");
		label_1.setAlignment(Label.CENTER);
		label_1.setBackground(SystemColor.info);
		label_1.setBounds(278, 28, 117, 22);
		panel_2.add(label_1);
		
		Label label_2 = new Label("Nombre clause SAT");
		label_2.setAlignment(Label.CENTER);
		label_2.setBackground(SystemColor.info);
		label_2.setBounds(278, 56, 117, 22);
		panel_2.add(label_2);
		
		Label tmp_ACS = new Label("");
		tmp_ACS.setBackground(Color.WHITE);
		tmp_ACS.setAlignment(Label.CENTER);
		tmp_ACS.setBounds(202, 0, 70, 22);
		panel_2.add(tmp_ACS);
		
		Label tmp_GA = new Label("");
		tmp_GA.setFont(new Font("Dialog", Font.BOLD, 12));
		tmp_GA.setForeground(new Color(51, 102, 153));
		tmp_GA.setBackground(Color.WHITE);
		tmp_GA.setAlignment(Label.CENTER);
		tmp_GA.setBounds(131, 0, 70, 22);
		panel_2.add(tmp_GA);
		
	
		
		Label tmp_A_etoile = new Label("");
		tmp_A_etoile.setBackground(Color.WHITE);
		tmp_A_etoile.setAlignment(Label.CENTER);
		tmp_A_etoile.setBounds(0, 0, 65, 22);
		panel_2.add(tmp_A_etoile);
		
		Label sp_ACS = new Label("");
		sp_ACS.setBackground(Color.WHITE);
		sp_ACS.setAlignment(Label.CENTER);
		sp_ACS.setBounds(202, 28, 70, 22);
		panel_2.add(sp_ACS);
		
		Label sp_GA = new Label("");
		sp_GA.setBackground(Color.WHITE);
		sp_GA.setAlignment(Label.CENTER);
		sp_GA.setBounds(131, 28, 70, 22);
		panel_2.add(sp_GA);
		
		Label sp_DFS = new Label("");
		sp_DFS.setBackground(Color.WHITE);
		sp_DFS.setAlignment(Label.CENTER);
		sp_DFS.setBounds(65, 28, 65, 22);
		panel_2.add(sp_DFS);
		
		Label sp_A_etoile = new Label("");
		sp_A_etoile.setBackground(Color.WHITE);
		sp_A_etoile.setAlignment(Label.CENTER);
		sp_A_etoile.setBounds(0, 28, 65, 22);
		panel_2.add(sp_A_etoile);
		
		Label SAT_ACS = new Label("");
		SAT_ACS.setBackground(Color.WHITE);
		SAT_ACS.setAlignment(Label.CENTER);
		SAT_ACS.setBounds(202, 56, 70, 22);
		panel_2.add(SAT_ACS);
		
		Label SAT_GA = new Label("");
		SAT_GA.setBackground(Color.WHITE);
		SAT_GA.setAlignment(Label.CENTER);
		SAT_GA.setBounds(131, 56, 70, 22);
		panel_2.add(SAT_GA);
		
		Label SAT_DFS = new Label("");
		SAT_DFS.setBackground(Color.WHITE);
		SAT_DFS.setAlignment(Label.CENTER);
		SAT_DFS.setBounds(65, 56, 65, 22);
		panel_2.add(SAT_DFS);
		
		Label SAT_A_etoile = new Label("");
		SAT_A_etoile.setBackground(Color.WHITE);
		SAT_A_etoile.setAlignment(Label.CENTER);
		SAT_A_etoile.setBounds(0, 56, 65, 22);
		panel_2.add(SAT_A_etoile);
		
		Label tmp_DFS = new Label("");
		tmp_DFS.setBackground(Color.WHITE);
		tmp_DFS.setAlignment(Label.CENTER);
		tmp_DFS.setBounds(65, 0, 65, 22);
		panel_2.add(tmp_DFS);
		
		TextArea textArea = new TextArea();
		textArea.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 12));
		textArea.setBounds(10, 183, 695, 93);
		MAXITER.add(textArea);
		
		JButton btn_visiter_Rapport = new JButton("Rapport");
		btn_visiter_Rapport.setForeground(new Color(51, 102, 153));
		btn_visiter_Rapport.setBounds(176, 154, 109, 23);
		MAXITER.add(btn_visiter_Rapport);
		
		JLabel lblNewLabel_7 = new JLabel("Affichage des solutions : ");
		lblNewLabel_7.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 11));
		lblNewLabel_7.setForeground(Color.WHITE);
		lblNewLabel_7.setBounds(44, 159, 156, 18);
		MAXITER.add(lblNewLabel_7);
		
		JPanel paramettre = new JPanel();
		paramettre.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.RAISED, new Color(51, 102, 153), new Color(51, 102, 153)), "Paramètres", TitledBorder.CENTER, TitledBorder.TOP, null, new Color(51, 102, 153)));
		paramettre.setBackground(new Color(211, 211, 211));
		paramettre.setBounds(410, 6, 295, 177);
		MAXITER.add(paramettre);
		paramettre.setLayout(null);
		
		JTextPane Max_iter = new JTextPane();
		Max_iter.setForeground(new Color(51, 102, 153));
		Max_iter.setBorder(new LineBorder(new Color(169, 169, 169), 2));
		Max_iter.setBounds(246, 21, 39, 18);
		paramettre.add(Max_iter);

		Max_iter.setBackground(Color.WHITE);
		
		JLabel maxitteration = new JLabel("Max itterations     ");
		maxitteration.setBackground(new Color(51, 102, 153));
		maxitteration.setBounds(154, 21, 92, 18);
		paramettre.add(maxitteration);
		maxitteration.setFont(new Font("Tahoma", Font.BOLD, 9));
		maxitteration.setForeground(new Color(51, 102, 153));
		maxitteration.setName("Maxitterations");
		
		JTextPane P_croisement_1 = new JTextPane();
		P_croisement_1.setForeground(new Color(51, 102, 153));
		P_croisement_1.setBorder(new LineBorder(new Color(169, 169, 169), 2));
		P_croisement_1.setBounds(246, 50, 39, 17);
		paramettre.add(P_croisement_1);
		P_croisement_1.setBackground(Color.WHITE);
		
		JLabel croisement_1 = new JLabel("P_croisement         ");
		croisement_1.setBounds(154, 50, 95, 17);
		paramettre.add(croisement_1);
		croisement_1.setForeground(new Color(51, 102, 153));
		croisement_1.setFont(new Font("Tahoma", Font.BOLD, 10));
		
		JTextPane Taille_pop = new JTextPane();
		Taille_pop.setForeground(new Color(51, 102, 153));
		Taille_pop.setBorder(new MatteBorder(2, 2, 2, 2, (Color) new Color(169, 169, 169)));
		Taille_pop.setBounds(246, 78, 39, 17);
		paramettre.add(Taille_pop);
		Taille_pop.setBackground(Color.WHITE);
		
		JLabel Taille = new JLabel("Taille_population  ");
		Taille.setBounds(154, 69, 92, 30);
		paramettre.add(Taille);
		Taille.setForeground(new Color(51, 102, 153));
		Taille.setFont(new Font("Tahoma", Font.BOLD, 10));
		Taille.setBackground(Color.WHITE);
		
		JTextPane P_mutation_1 = new JTextPane();
		P_mutation_1.setForeground(new Color(51, 102, 153));
		P_mutation_1.setBorder(new LineBorder(new Color(169, 169, 169), 2));
		P_mutation_1.setBounds(246, 106, 39, 18);
		paramettre.add(P_mutation_1);
		P_mutation_1.setBackground(Color.WHITE);
		
		JLabel mutation_1 = new JLabel("P_mutation            ");
		mutation_1.setBounds(154, 106, 96, 18);
		paramettre.add(mutation_1);
		mutation_1.setFont(new Font("Tahoma", Font.BOLD, 10));
		mutation_1.setForeground(new Color(51, 102, 153));
		
		JTextPane k_points = new JTextPane();
		k_points.setForeground(new Color(51, 102, 153));
		k_points.setBorder(new LineBorder(new Color(169, 169, 169), 2));
		k_points.setBounds(246, 134, 39, 18);
		paramettre.add(k_points);
		k_points.setBackground(new Color(255, 255, 255));
		
		JLabel Points = new JLabel("K_points    ");
		Points.setBounds(154, 134, 66, 18);
		paramettre.add(Points);
		Points.setFont(new Font("Tahoma", Font.BOLD, 10));
		Points.setForeground(new Color(51, 102, 153));
		
		JTextPane Val_Seuil = new JTextPane();
		Val_Seuil.setForeground(new Color(51, 102, 153));
		Val_Seuil.setBorder(new LineBorder(new Color(169, 169, 169), 2));
		Val_Seuil.setBounds(52, 21, 39, 18);
		paramettre.add(Val_Seuil);
		
		JLabel Seuil = new JLabel(" Seuil     ");
		Seuil.setBounds(20, 21, 61, 18);
		paramettre.add(Seuil);
		Seuil.setFont(new Font("Tahoma", Font.BOLD, 10));
		Seuil.setForeground(new Color(0, 102, 153));
		
		JLabel Max_itterations = new JLabel("Max itterations");
		Max_itterations.setFont(new Font("Tahoma", Font.BOLD, 10));
		Max_itterations.setForeground(new Color(51, 102, 153));
		Max_itterations.setBounds(10, 50, 76, 30);
		paramettre.add(Max_itterations);
		
		JLabel NBR_fourmis = new JLabel("Nbr fourmis");
		NBR_fourmis.setFont(new Font("Tahoma", Font.BOLD, 10));
		NBR_fourmis.setForeground(new Color(51, 102, 153));
		NBR_fourmis.setBounds(10, 78, 75, 30);
		paramettre.add(NBR_fourmis);
		
		JLabel alpha = new JLabel("\u03B1");
		alpha.setForeground(new Color(51, 102, 153));
		alpha.setBackground(new Color(51, 102, 153));
		alpha.setFont(new Font("Tahoma", Font.BOLD, 10));
		alpha.setBounds(83, 147, 17, 24);
		paramettre.add(alpha);
		
		JLabel beta = new JLabel("\u03B2");
		beta.setFont(new Font("Tahoma", Font.BOLD, 10));
		beta.setForeground(new Color(51, 102, 153));
		beta.setBounds(10, 153, 27, 18);
		paramettre.add(beta);
		
		JTextPane val_alpha = new JTextPane();
		val_alpha.setBounds(105, 153, 39, 18);
		val_alpha.setBorder(new LineBorder(new Color(169, 169, 169), 2));
		paramettre.add(val_alpha);
		
		JTextPane val_beta = new JTextPane();
		val_beta.setBounds(34, 153, 39, 18);
		val_beta.setBorder(new LineBorder(new Color(169, 169, 169), 2));
		paramettre.add(val_beta);
		
		JTextPane val_nbr_fourmis = new JTextPane();
		val_nbr_fourmis.setBounds(105, 88, 39, 18);
		val_nbr_fourmis.setBorder(new LineBorder(new Color(169, 169, 169), 2));
		paramettre.add(val_nbr_fourmis);
		
		JTextPane val_maxiter = new JTextPane();
		val_maxiter.setBounds(105, 59, 39, 18);
		val_maxiter.setBorder(new LineBorder(new Color(169, 169, 169), 2));
		paramettre.add(val_maxiter);
		
		JLabel Q0 = new JLabel("Q0");
		Q0.setFont(new Font("Tahoma", Font.BOLD, 10));
		Q0.setForeground(new Color(51, 102, 153));
		Q0.setBounds(10, 117, 46, 30);
		paramettre.add(Q0);
		
		JTextPane val_Q0 = new JTextPane();
		val_Q0.setBounds(34, 123, 39, 18);
		val_Q0.setBorder(new LineBorder(new Color(169, 169, 169), 2));
		paramettre.add(val_Q0);
		
		JTextPane val_pheromone = new JTextPane();
		val_pheromone.setBounds(105, 31, 39, 18);
		val_pheromone.setBorder(new LineBorder(new Color(169, 169, 169), 2));
		paramettre.add(val_pheromone);
		
		JLabel pheromone_initiale = new JLabel("Pheromone initiale");
		pheromone_initiale.setFont(new Font("Tahoma", Font.BOLD, 10));
		pheromone_initiale.setForeground(new Color(51, 102, 153));
		pheromone_initiale.setBounds(10, 21, 95, 41);
		paramettre.add(pheromone_initiale);
		
		JTextPane val_taux = new JTextPane();
		val_taux.setBounds(105, 124, 39, 18);
		val_taux.setBorder(new LineBorder(new Color(169, 169, 169), 2));
		paramettre.add(val_taux);
		
		JLabel Taux_evaporation = new JLabel("T");
		Taux_evaporation.setFont(new Font("Tahoma", Font.BOLD, 10));
		Taux_evaporation.setForeground(new Color(51, 102, 153));
		Taux_evaporation.setBounds(83, 123, 82, 18);
		paramettre.add(Taux_evaporation);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(Interface_BIO.class.getResource("/Image/verified (7) (1).png")));
		lblNewLabel.setBounds(12, 146, 48, 37);
		MAXITER.add(lblNewLabel);
		
		JLabel lblNewLabel_6 = new JLabel("Méthodes :");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 11));
		lblNewLabel_6.setForeground(new Color(255, 255, 255));
		lblNewLabel_6.setBounds(44, 8, 65, 14);
		MAXITER.add(lblNewLabel_6);
		
		JLabel lblNewLabel_8 = new JLabel("");
		lblNewLabel_8.setIcon(new ImageIcon(Interface_BIO.class.getResource("/Image/gears (4) (2).png")));
		lblNewLabel_8.setBounds(12, 0, 48, 30);
		MAXITER.add(lblNewLabel_8);
		
		Seuil.setVisible(false);
		Val_Seuil.setVisible(false);
		
		mutation_1.setVisible(false);
		P_mutation_1.setVisible(false);
		
		k_points.setVisible(false);
		Points.setVisible(false);
		
		Taille.setVisible(false);
		Taille_pop.setVisible(false);
		
		croisement_1.setVisible(false);
		P_croisement_1.setVisible(false);
		
		maxitteration.setVisible(false);
		Max_iter.setVisible(false);
		
		maxitteration.setVisible(false);
		Max_iter.setVisible(false);

		
		NBR_fourmis.setVisible(false);
		val_nbr_fourmis.setVisible(false);
		
		val_maxiter.setVisible(false);
		Max_itterations.setVisible(false);
		
		alpha.setVisible(false);
		val_alpha.setVisible(false);
		
		beta.setVisible(false);
		val_beta.setVisible(false);
		
		Q0.setVisible(false);
		val_Q0.setVisible(false);
		
		pheromone_initiale.setVisible(false);
		val_pheromone.setVisible(false);
		
		
		Taux_evaporation.setVisible(false);
		val_taux.setVisible(false);
		
		btn_visiter_Rapport.setVisible(false);
		btn_visiter_Rapport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				fenetre.setVisible(true);
			}
		});
JLabel lblNewLabel_4 = new JLabel("");
lblNewLabel_4.setBounds(10, -13, 248, 95);
lblNewLabel_4.setIcon(new ImageIcon(Interface_BIO.class.getResource("/Image/MethodeLogo (2).png")));
panel.add(lblNewLabel_4);
JLabel btn_sortir = new JLabel("");
btn_sortir.setBounds(679, 375, 63, 40);
btn_sortir.setIcon(new ImageIcon(Interface_BIO.class.getResource("/Image/LOGOUT.png")));
panel.add(btn_sortir);

btn_sortir.addMouseListener(new MouseAdapter() {
	@Override
	public void mouseClicked(MouseEvent arg0) {
		System.exit(0);
	}
});

JLabel lblBioInspir = new JLabel("Bio Inspire\u00E9");
lblBioInspir.setBounds(216, 11, 412, 53);
lblBioInspir.setForeground(new Color(255, 255, 255));
lblBioInspir.setBackground(new Color(255, 255, 255));
lblBioInspir.setFont(new Font("Script MT Bold", Font.BOLD | Font.ITALIC, 59));
panel.add(lblBioInspir);

JLabel lblNewLabel_5 = new JLabel("");
lblNewLabel_5.setBounds(-195, 0, 929, 415);
lblNewLabel_5.setIcon(new ImageIcon(Interface_BIO.class.getResource("/Image/00106-3D-company-logos-design-free-logo-online-02.png")));
panel.add(lblNewLabel_5);
/****************************************************** Traitement button DFS  **********************************************************/
                                                       ///////////////////////
 
btn_DFS.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
		//button Ga
		mutation_1.setVisible(false);
		P_mutation_1.setVisible(false);		
		k_points.setVisible(false);
		Points.setVisible(false);		
		Taille.setVisible(false);
		Taille_pop.setVisible(false);		
		croisement_1.setVisible(false);
		P_croisement_1.setVisible(false);		
		maxitteration.setVisible(false);
		Max_iter.setVisible(false);
		//button acs
		NBR_fourmis.setVisible(false);
		val_nbr_fourmis.setVisible(false);
		val_maxiter.setVisible(false);
		Max_itterations.setVisible(false);   			
		alpha.setVisible(false);
		val_alpha.setVisible(false);   			
		beta.setVisible(false);
		val_beta.setVisible(false);   			
		Q0.setVisible(false);
		val_Q0.setVisible(false);    			
		pheromone_initiale.setVisible(false);
		val_pheromone.setVisible(false);   			
		Taux_evaporation.setVisible(false);
		val_taux.setVisible(false);
  if(click!=1) {
		JOptionPane.showMessageDialog(null, "Veuillez valider le fichier svp!", "ERREUR ",
				JOptionPane.ERROR_MESSAGE);
		return;  
   }
		if (URL_fichier.getText().equals("")) {
			JOptionPane.showMessageDialog(null, "Le chemin du fichier à traiter n'existe pas!", "ERREUR ",
					JOptionPane.ERROR_MESSAGE);
			return;
		} else {
			Recherche_Profondeur R = new Recherche_Profondeur();
			
			try {
				Seuil.setVisible(true);
				Val_Seuil.setVisible(true);
				Boolean b=true;
				try {
				int i = Integer.parseInt(Val_Seuil.getText().trim());
				
				}catch (NumberFormatException e1) {
					// TODO: handle exception
					b=false;	
				}
				
				Val_Seuil.setText(Val_Seuil.getText().trim());
				if(click==1) {
				if (Val_Seuil.getText().equals("")|| b==false ) {
					
					JOptionPane.showMessageDialog(null, "Veuillez saisie un seuil SVP!", "ERREUR ",JOptionPane.ERROR_MESSAGE);
					Val_Seuil.setText("");
					return;
				} 
				}
				    String separator = "\\";
					String[] str_arr=path.replaceAll(Pattern.quote(separator), "\\\\").split("\\\\");
					
					String p= Val_Seuil.getText();
					int S=Integer.parseInt(p);
					
					String l=R.Recherche_profond(EC,S);
					
					 val = R.getNombre_clauses_SAT();
					
					SAT_DFS.setText(String.valueOf(val));
					textArea.append("\n"+"\n"+"Parcour DFS :"+"\n"+"---------------------"+"\n"+l+"\n");
					 val2 = R.get_tmp();
					tmp_DFS.setText(String.valueOf(val2) + " ms");
					 val3 = R.get_sp();
					sp_DFS.setText(String.valueOf(val3)+ " MO");
					long s=Long.valueOf(S);
					Modele m =new Modele(val,val2,val3,s,str_arr[str_arr.length-1]);
					MODELES.add(m);
					fenetre.dispose();
					fenetre=new Affichage();
					fenetre.Affichage(MODELES,n);
					fenetre.Affichage2(MODELES_A,n);
					fenetre.Affichage3(MODELES_GA,n);
					btn_visiter_Rapport.setVisible(true);
			        
			        
			/*		BarChartExample B=new BarChartExample(table);
					CategoryDataset c= B.createDataset(table);
					      B.setSize(800, 400);  
					      B.setLocationRelativeTo(null);  
					      B.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);  
					      B.setVisible(true); */
				}
			 catch (InterruptedException e1) {
				// TODO Auto-generated catch block 
				e1.printStackTrace();
			}
        }
	}
});
/****************************************************** Traitement button A_etoile  **********************************************************/
                                                      
 btn_A_etoile.addActionListener(new ActionListener() {
	 
	public void actionPerformed(ActionEvent e) {
		Seuil.setVisible(false);
		Val_Seuil.setVisible(false);
		
		mutation_1.setVisible(false);
		P_mutation_1.setVisible(false);
		
		k_points.setVisible(false);
		Points.setVisible(false);
		
		Taille.setVisible(false);
		Taille_pop.setVisible(false);
		
		croisement_1.setVisible(false);
		P_croisement_1.setVisible(false);
		
		maxitteration.setVisible(false);
		Max_iter.setVisible(false);
		
		   if(click!=1) {
				JOptionPane.showMessageDialog(null, "Veuillez valider le fichier svp!", "ERREUR ",
						JOptionPane.ERROR_MESSAGE);
				return;  
		   }
        if(URL_fichier.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null,"Le chemin du fichier à traiter n'existe pas!","ERREUR ",JOptionPane.ERROR_MESSAGE);
            return;
        }else {
        	

			A_etoile A= new A_etoile();	
			try {
			    String separator = "\\";
				String[] str_arr=path.replaceAll(Pattern.quote(separator), "\\\\").split("\\\\");
				String D=A.Parcours_A_etoile(EC);
				 val6=A.getNombr_clauses_SAT();
				SAT_A_etoile.setText(String.valueOf(val6));
				textArea.append("\n"+"Parcour A* :"+"\n"+"-------------------"+"\n"+D);
				 val4=A.getMili();
				tmp_A_etoile.setText(String.valueOf(val4)+" ms");
				 val5=A.getMem_utilise_A();
				sp_A_etoile.setText(String.valueOf(val5)+" MO");
				Modele m2 =new Modele(val6,val4,val5,str_arr[str_arr.length-1]);
				MODELES_A.add(m2);
				
				fenetre.dispose();
				fenetre=new Affichage();
				fenetre.Affichage(MODELES,n);
				fenetre.Affichage2(MODELES_A,n);
				fenetre.Affichage3(MODELES_GA,n);
				btn_visiter_Rapport.setVisible(true);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        }
	}
});
 
 /*********************************************************************************************/
 btn_GA.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			Seuil.setVisible(false);
			Val_Seuil.setVisible(false);
			   if(click!=1) {
					JOptionPane.showMessageDialog(null, "Veuillez valider le fichier svp!", "ERREUR ",
							JOptionPane.ERROR_MESSAGE);
					return;  
			   }
	        if(URL_fichier.getText().equals(""))
	        {
	            JOptionPane.showMessageDialog(null,"Le chemin du fichier à traiter n'existe pas!","ERREUR ",JOptionPane.ERROR_MESSAGE);
	            return;
	        }else {


    			mutation_1.setVisible(true);
    			P_mutation_1.setVisible(true);
    			Max_iter.setVisible(true);
    			maxitteration.setVisible(true);
    			P_croisement_1.setVisible(true);
    			croisement_1.setVisible(true);
    			k_points.setVisible(true);
    			Points.setVisible(true);
				Taille.setVisible(true);
    			Taille_pop.setVisible(true);
    			Max_iter.setVisible(true);
    			maxitteration.setVisible(true);
    			//button acs
    			NBR_fourmis.setVisible(false);
    			val_nbr_fourmis.setVisible(false);
    			val_maxiter.setVisible(false);
    			Max_itterations.setVisible(false);   			
    			alpha.setVisible(false);
    			val_alpha.setVisible(false);   			
    			beta.setVisible(false);
    			val_beta.setVisible(false);   			
    			Q0.setVisible(false);
    			val_Q0.setVisible(false);    			
    			pheromone_initiale.setVisible(false);
    			val_pheromone.setVisible(false);   			
    			Taux_evaporation.setVisible(false);
    			val_taux.setVisible(false);
    			
      			Boolean E=true;
    			try {
    				int i = Integer.parseInt(Max_iter.getText().trim());
    				
    				}catch (NumberFormatException e1) {
    					// TODO: handle exception
    					E=false;	
    				}
    			Max_iter.setText(Max_iter.getText().trim());
				if(click==1) {
				if (Max_iter.getText().equals("")|| E==false ) {
					JOptionPane.showMessageDialog(null, "Veuillez saisie un maximum nombre d'ittération SVP!", "ERREUR ",JOptionPane.ERROR_MESSAGE);
					Max_iter.setText("");
					return;
				}
				}
				
    			
    			Boolean D=true;
    			try {
    				float i = Float.parseFloat(P_croisement_1.getText().trim());
    				
    				}catch (NumberFormatException e1) {
    					// TODO: handle exception
    					D=false;	
    				}
    			 P_croisement_1.setText(P_croisement_1.getText().trim());
 				if(click==1) {
 				if (P_croisement_1.getText().equals("")|| D==false ) {
 					JOptionPane.showMessageDialog(null, "Veuillez saisie taux de croisement SVP!", "ERREUR ",JOptionPane.ERROR_MESSAGE);
 					P_croisement_1.setText("");
 					return;
 				} }

 				
    			Boolean F=true;
    			try {
    				int i = Integer.parseInt(Taille_pop.getText().trim());
    				
    				}catch (NumberFormatException e1) {
    					// TODO: handle exception
    					F=false;	
    				}
    			Taille_pop.setText(Taille_pop.getText().trim());
				if(click==1) {
				if (Taille_pop.getText().equals("")|| F==false ) {
					JOptionPane.showMessageDialog(null, "Veuillez saisie une Taille  pour la population SVP!", "ERREUR ",JOptionPane.ERROR_MESSAGE);
					Taille_pop.setText("");
					return;
				} }
				
    			Boolean C=true;
    			try {
    				float i = Float.parseFloat(P_mutation_1.getText().trim());
    				
    				}catch (NumberFormatException e1) {
    					// TODO: handle exception
    					C=false;	
    				}
				
    			 P_mutation_1.setText(P_mutation_1.getText().trim());
 				if(click==1) {
 				if (P_mutation_1.getText().equals("")|| C==false ) {
 					
 					JOptionPane.showMessageDialog(null, "Veuillez saisie un taux de mutation!", "ERREUR ",JOptionPane.ERROR_MESSAGE);
 					P_mutation_1.setText("");
 					return;
 				} }
 				
 				
	  			Boolean G=true;
    			try {
    				int i = Integer.parseInt(k_points.getText().trim());
    				
    				}catch (NumberFormatException e1) {
    					// TODO: handle exception
    					G=false;	
    				}
    			k_points.setText(k_points.getText().trim());
				if(click==1) {
				if (k_points.getText().equals("")|| G==false ) {
					JOptionPane.showMessageDialog(null, "Veuillez saisie le K_points et il doit etre de type entier ", "ERREUR ",JOptionPane.ERROR_MESSAGE);
					k_points.setText("");
					return;
				} }
				

    			String max=Max_iter.getText();
    			int MAX_itter=Integer.parseInt(max);
    			
    			String taille=Taille_pop.getText();
    			int taille_population=Integer.parseInt(taille);
    			
                String mutation=  P_mutation_1.getText();
                float P_mutation=Float.parseFloat(mutation);
                
                String croisement=  P_croisement_1.getText();
                float P_croisement=Float.parseFloat(croisement);

    			
      			String Kpoints=k_points.getText();
    			int k_point=Integer.parseInt(Kpoints);
    			
    			Recherche_GA GS=new Recherche_GA (taille_population,MAX_itter,P_croisement,P_mutation,EC);
    			try {
    			    String separator = "\\";
    				String[] str_arr=path.replaceAll(Pattern.quote(separator), "\\\\").split("\\\\");
    				
        			String SaT=GS.GA( k_point);
        			 SATG= GS.getNbr_SATG();
					SAT_GA.setText(String.valueOf(SATG));
					 MILI= GS.getMili();
					tmp_GA.setText(String.valueOf(MILI)+"ms");
					 ESPACE=GS.getMem_utilise_GA();;
					sp_GA.setText(String.valueOf(ESPACE)+"Mo");
					textArea.append("\n"+"Algorithme GA :"+"\n"+"---------------------"+"\n"+SaT+"\n"+"\n");
					
					Modele m3 =new Modele(SATG,MILI,ESPACE,MAX_itter,P_croisement,taille_population,P_mutation,k_point,str_arr[str_arr.length-1]);
					MODELES_GA.add(m3);
					fenetre.dispose();
					fenetre=new Affichage();
					fenetre .Affichage(MODELES,n);
					fenetre .Affichage2(MODELES_A,n);
					fenetre .Affichage3(MODELES_GA,n);
					btn_visiter_Rapport.setVisible(true);
        			} catch (InterruptedException e1) {
        				// TODO Auto-generated catch block
        				e1.printStackTrace();
        				
        			}
    			
		}
	        
		}  
	});
//btn**************************************************************************************************
 
 btn_ACS.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			Seuil.setVisible(false);
			Val_Seuil.setVisible(false);
			
			mutation_1.setVisible(false);
			P_mutation_1.setVisible(false);
			
			k_points.setVisible(false);
			Points.setVisible(false);
			
			Taille.setVisible(false);
			Taille_pop.setVisible(false);
			
			croisement_1.setVisible(false);
			P_croisement_1.setVisible(false);
			
			maxitteration.setVisible(false);
			Max_iter.setVisible(false);
			
			 if(click!=1) {
					JOptionPane.showMessageDialog(null, "Veuillez valider le fichier svp!", "ERREUR ",
							JOptionPane.ERROR_MESSAGE);
					return;  
			   }
					if (URL_fichier.getText().equals("")) {
						JOptionPane.showMessageDialog(null, "Le chemin du fichier à traiter n'existe pas!", "ERREUR ",
								JOptionPane.ERROR_MESSAGE);
						return;}
			
			NBR_fourmis.setVisible(true);
			val_nbr_fourmis.setVisible(true);
			
			val_maxiter.setVisible(true);
			Max_itterations.setVisible(true);
			
			alpha.setVisible(true);
			val_alpha.setVisible(true);
			
			beta.setVisible(true);
			val_beta.setVisible(true);
			
			Q0.setVisible(true);
			val_Q0.setVisible(true);
			
			pheromone_initiale.setVisible(true);
			val_pheromone.setVisible(true);
			
			Taux_evaporation.setVisible(true);
			val_taux.setVisible(true);
			Boolean r=true;
			try {
				float i = Float.parseFloat(val_pheromone.getText().trim());
				
				}catch (NumberFormatException e1) {
					// TODO: handle exception
					r=false;	
				}
			val_pheromone.setText(val_pheromone.getText().trim());
				if(click==1) {
				if (val_pheromone.getText().equals("")|| r==false ) {
					JOptionPane.showMessageDialog(null, "Veuillez saisie la valeur initiale de pheromone SVP!", "ERREUR ",JOptionPane.ERROR_MESSAGE);
					val_pheromone.setText("");
					return;
				} }
				
		          Boolean max=true;
					try {
						float i = Float.parseFloat(val_maxiter.getText().trim());
						
						}catch (NumberFormatException e1) {
							// TODO: handle exception
							max=false;	
						}
					val_maxiter.setText(val_maxiter.getText().trim());
						if(click==1) {
						if (val_maxiter.getText().equals("")|| max==false ) {
							JOptionPane.showMessageDialog(null, "Veuillez saisie le nombre maximum d'itterations SVP!", "ERREUR ",JOptionPane.ERROR_MESSAGE);
							val_maxiter.setText("");
							return;
						} }
						
            Boolean nbr=true;
			try {
				float i = Float.parseFloat(val_nbr_fourmis.getText().trim());
				
				}catch (NumberFormatException e1) {
					// TODO: handle exception
					nbr=false;	
				}
			val_nbr_fourmis.setText(val_nbr_fourmis.getText().trim());
				if(click==1) {
				if (val_nbr_fourmis.getText().equals("")|| nbr==false ) {
					JOptionPane.showMessageDialog(null, "Veuillez saisie  le nombre de fourmis SVP!", "ERREUR ",JOptionPane.ERROR_MESSAGE);
					val_nbr_fourmis.setText("");
					return;
				} }
				
				   Boolean a=true;
					try {
						float i = Float.parseFloat(val_alpha.getText().trim());
						
						}catch (NumberFormatException e1) {
							// TODO: handle exception
							a=false;	
						}
					
					
					Boolean Q=true;
					try {
						float i = Float.parseFloat(val_Q0.getText().trim());
						
						}catch (NumberFormatException e1) {
							// TODO: handle exception
							Q=false;	
						}
					val_Q0.setText(val_Q0.getText().trim());
						if(click==1) {
						if (val_Q0.getText().equals("")|| Q==false ) {
							JOptionPane.showMessageDialog(null, "Veuillez saisie la valeur de paramètre Q0 SVP!", "ERREUR ",JOptionPane.ERROR_MESSAGE);
							val_Q0.setText("");
							return;
						} }
						
						
			            Boolean T=true;
						try {
							float i = Float.parseFloat(val_taux.getText().trim());
							
							}catch (NumberFormatException e1) {
								// TODO: handle exception
								T=false;	
							}
						val_taux.setText(val_taux.getText().trim());
							if(click==1) {
							if (val_taux.getText().equals("")|| T==false ) {
								JOptionPane.showMessageDialog(null, "Veuillez saisie la valeur de taux d'evaporation T  SVP!", "ERREUR ",JOptionPane.ERROR_MESSAGE);
								val_taux.setText("");
								return;
							} }
			
							
		            Boolean B=true;
					try {
						float i = Float.parseFloat(val_beta.getText().trim());
						
						}catch (NumberFormatException e1) {
							// TODO: handle exception
							B=false;	
						}
					val_beta.setText(val_beta.getText().trim());
						if(click==1) {
						if (val_beta.getText().equals("")|| B==false ) {
							JOptionPane.showMessageDialog(null, "Veuillez saisie la valeur de paramètre β SVP!", "ERREUR ",JOptionPane.ERROR_MESSAGE);
							val_beta.setText("");
							return;
						} }
						
					val_alpha.setText(val_alpha.getText().trim());
						if(click==1) {
						if (val_alpha.getText().equals("")|| a==false ) {
							JOptionPane.showMessageDialog(null, "Veuillez saisie la valeur de paramètre α SVP!", "ERREUR ",JOptionPane.ERROR_MESSAGE);
							val_alpha.setText("");
							return;
						} }
			
		    String separator = "\\";
			String[] str_arr=path.replaceAll(Pattern.quote(separator), "\\\\").split("\\\\");
			
			//nbr fourmis 
			String nbr_f=val_nbr_fourmis.getText();
			int nbr_F=Integer.parseInt(nbr_f);
			//max itteration
			String max_itter =val_maxiter.getText();
			int max_itetr=Integer.parseInt(max_itter);
			//alpha
         String alpha=  val_alpha.getText();
         double Alpha=Double.parseDouble(alpha);
         //beta
         String beta=  val_beta.getText();
         double Beta=Double.parseDouble(beta);
         //Q0
         String Q0=  val_Q0.getText();
         double q0=Double.parseDouble(Q0);
         //taux
         String taux=  val_taux.getText();
         double Taux=Double.parseDouble(taux);
         //ph
         String pheromone_initial=  val_pheromone.getText();
         double ro=Double.parseDouble(pheromone_initial);
         
			
			try {
			    String separators = "\\";
				String[] str_arrs=path.replaceAll(Pattern.quote(separators), "\\\\").split("\\\\");
				ACS A = new ACS(max_itetr, nbr_F,Alpha,Beta,EC,Taux,q0,ro);
				String resultat=A.Execution_ACS();
				textArea.append("\n"+"Algorithme ACS:"+"\n"+"---------------------"+"\n"+resultat+"\n"+"\n");
				SAT_ACS.setText(String.valueOf(A.get_fitness()));
				sat_acs=A.get_fitness();
				tmp_ACS.setText(String.valueOf(A.get_tmp_acs())+"ms");
				tmp_acs=A.get_tmp_acs();
				sp_ACS.setText(String.valueOf(A.get_sp_acs())+"Mo");
				sp_acs=A.get_sp_acs();
				Modele m4 =new Modele(sat_acs,tmp_acs,sp_acs,max_itetr,nbr_F,Alpha,Beta,Taux,q0,ro,str_arrs[str_arrs.length-1]);
				MODELES_ACS.add(m4);
				fenetre.dispose();
				fenetre=new Affichage();
				fenetre .Affichage(MODELES,n);
				fenetre .Affichage2(MODELES_A,n);
				fenetre .Affichage3(MODELES_GA,n);
				fenetre .Affichage4(MODELES_ACS,n);
				btn_visiter_Rapport.setVisible(true);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			
		}
	});
 
 
 
	}	
}
