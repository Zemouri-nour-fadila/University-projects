package Interface;

public class Modele {
	public long sat;
	public long tmp ;
	public long sp;
	public long s;
	public int iter;
	public float pc ;
	public int tp;
	public float pm;
	public int kp;
	public String p;
	public int max_itetr;
	public int nbr_F;
	public double Alpha;
	public double Beta;
	public double Taux;
	public double q0;
	public double ro;
	
	public Modele(long sat, long tmp , long sp , long s , String p) {
		this.sat=sat;
		this.tmp=tmp;
		this.sp=sp;
		this.s=s;
		this.p=p;
	}
	public Modele(long sat, long tmp , long sp , String p) {
		this.sat=sat;
		this.tmp=tmp;
		this.sp=sp;
		this.p=p;
	}
	public Modele(long sat, long tmp , long sp , int iter,float pc ,int tp,float pm,int kp , String p) {
		this.sat=sat;
		this.tmp=tmp;
		this.sp=sp;
		this.iter=iter;
		this.pc=pc;
		this.tp=tp;
		this.pm=pm;
		this.kp=kp;
		this.p=p;
	}
	public Modele(int sat, long tmp , long sp , int max_itetr , int nbr_F,double Alpha,double Beta,double Taux,double q0, double ro,String p) {
		this.sat=sat;
		this.tmp=tmp;
		this.sp=sp;
		this.s=s;
		this.p=p;
		this.nbr_F=nbr_F;
		this.ro=ro;
		this.Alpha=Alpha;
		this.Beta=Beta;
		this.q0=q0;
		this.Taux=Taux;
		this.max_itetr=max_itetr;
		
	}
}

