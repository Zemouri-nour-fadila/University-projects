package Interface;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.border.LineBorder;
import javax.swing.JLabel;
import javax.swing.JSlider;
import javax.swing.UIManager;
import javax.swing.JProgressBar;
import javax.swing.ImageIcon;
import java.awt.Font;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.SwingConstants;
import java.awt.Rectangle;

public class progress extends JFrame {

	public JLabel lib;
	public JProgressBar bp;

	/**
	 * lancer l'application
	 */
	public static void main(String[] args) {
		progress window = null;
		 try { 
	            UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
	            window = new progress();
	           
	        } catch (Exception ex) { 
	            ex.printStackTrace(); 
	        }
		Interface_BIO BIO = new Interface_BIO();
		window.dispose();
		BIO.getFrmBioInsp().setVisible(true); 
	}

	/**
	 * creation de l'application.
	 */
	public progress() {
		getContentPane().setBackground(new Color(0, 102, 153));
		setUndecorated(true);
		setBounds(new Rectangle(150, 10, 435, 260));
		setResizable(false);
		initialize();
		 this.setLocationRelativeTo(null);
		this.setVisible(true);
		try {
            for(int i=0;i<=100;i++) {
				Thread.sleep(20);
		        this.lib.setText(Integer.toString(i)+"%");
				this.bp.setValue(i);
			}
		} catch (Exception e) {
            Logger.getLogger(progress.class.getName()).log(Level.SEVERE, null, e);
		}
	}

	/**
	 * Initialization les contents de  frame. 
	 */
	private void initialize() {

		JPanel panel = new JPanel();
		panel.setVerifyInputWhenFocusTarget(false);
		panel.setBackground(new Color(0, 102, 153));
		panel.setBounds(200, 200, 434, 261);
		this.getContentPane().add(panel);
		panel.setLayout(null);

		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(new Color(0, 102, 153), 7, true));
		panel_1.setBackground(new Color(255, 255, 255));
		panel_1.setBounds(10, 11, 414, 239);
		panel.add(panel_1);
		panel_1.setLayout(null);

		JPanel panel_2 = new JPanel();
		panel_2.setBounds(10, 11, 394, 217);
		panel_2.setBorder(new LineBorder(new Color(0, 102, 153), 10));
		panel_2.setBackground(new Color(255, 255, 255));
		panel_1.add(panel_2);
		panel_2.setLayout(null);

		JPanel panel_3 = new JPanel();
		panel_3.setBackground(Color.WHITE);
		panel_3.setBorder(new LineBorder(new Color(0, 102, 153)));
		panel_3.setBounds(10, 11, 374, 195);
		panel_2.add(panel_3);
		panel_3.setLayout(null);

		JLabel lblNewLabel_1 = new JLabel("Loading ...");
		lblNewLabel_1.setBounds(244, 0, 142, 30);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 24));
		lblNewLabel_1.setForeground(new Color(0, 102, 153));
		panel_3.add(lblNewLabel_1);
		
		lib = new JLabel("100%");
		lib.setFont(new Font("Dialog", Font.BOLD, 20));
		lib.setForeground(new Color(0, 102, 153));
		lib.setHorizontalAlignment(SwingConstants.CENTER);
		lib.setBackground(Color.WHITE);
		lib.setBounds(23, 95, 352, 26);
		panel_3.add(lib);

		bp = new JProgressBar();
		bp.setEnabled(false);
		bp.setBounds(10, 140, 354, 30);
		panel_3.add(bp);

		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(-26, -66, 526, 282);
		panel_3.add(lblNewLabel);
		lblNewLabel.setIcon(new ImageIcon(progress.class.getResource("/Image/load (2).png")));

	}
}
