package Partie1;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Stack;

import Structure.EnsembleClauses;
import Structure.Literale;
import Structure.Noeud;

public class A_etoile {
	private ArrayList<Literale> LITS = new ArrayList<Literale>();
	// Relever l'heure avant le debut du progamme (en milliseconde)
	//-------------------------------------------------------------
	java.util.Date Debut_execution = new java.util.Date(System.currentTimeMillis()); 
	// l'�l�ment racine de l'arbre
	// -----------------------------
	private static Noeud root = new Noeud();

	private int Nombre_clauses_SAT;// nombre des clause _SAT
    private long mili;
    private long mem_utilise_A;
    
	public String Parcours_A_etoile(EnsembleClauses EC) throws InterruptedException {

		// Ouverte : Liste initialement vide :
		// -----------------------------------
		Stack<Noeud> Ouvert = new Stack<Noeud>();

		// Fermer : File initialement vide :
		// -----------------------------------
		Stack<Noeud> Fermer = new Stack<Noeud>();

		// 1- Initialiser la liste des clauses SAT ={vide} :
		// -----------------------------------------------
		Noeud SAT = root;

		// 2- Inserer la racine (Literal)
		// ------------------------------
		Ouvert.push(root);

		// Un litt�ral temporaire utilis� pour manipuler le litt�ral s�lectionn�
		// -----------------------------------------------------------------------
		Literale Literal_selected;

		// 3- v�rifier que la pile ouverte n'est pas vide (car si elle est vide on a
		// aucun Literal � instancier)
		// -------------------------------------------------------------------------
		while (!Ouvert.isEmpty()) {

			// Retirer le root de la liste ouverte et l'enfiler dans fermer
			// -------------------------------------------------------------
			SAT = Ouvert.pop();
			Fermer.push(SAT);

			// Calcule le nombre de clause satisfaite pour arr�ter la recherche ou continuer
			// -----------------------------------------------------------------------------
			Nombre_clauses_SAT = EC.Nombre_Clauses_SAT(SAT);
			// V�rifier si Nmbre_Clause_SAT=nombre des clauses => nous avons trouv� une
			// solution pour arriter la recherche
			// -------------------------------------------------------------------------
			if (Nombre_clauses_SAT == EC.getClauses().size()) {
				Date FIN_exection = new Date(System.currentTimeMillis()); // Relever l'heure a la fin du progamme (en
																			// milliseconde)
				Date duree = new Date(System.currentTimeMillis()); // Pour calculer la diff�rence
				duree.setTime(FIN_exection.getTime() - Debut_execution.getTime()); // Calcul de la diff�rence
				 mili = duree.getTime() % 1000;
				LITS=SAT.lists();
				return SAT.toString();
			}

			// S�lectionnez le lit�ral avec la meilleur valeur de fitness :
			// -------------------------------------------------------------
			Literal_selected = Literale.SeLect_Lit(EC, SAT);

			// V�rifie le s�lectionn� s'il est <> null (car si il est = null alors
			// L'instance courrant contient tout les litt�raux)
			// -------------------------------------------------------------------
			if (Literal_selected != null) {

				// Creation d'un chainage
				// -----------------------
				Noeud X1 = new Noeud();

				X1.setPrecedent(SAT);

				X1.setLit_N(new Literale(Literal_selected.getnumero(), Literal_selected.getEtat(),
						Literal_selected.getvaleur()));

				// Ajoute les n�uds cr��s dans la liste ouverte
				// --------------------------------------------
				Ouvert.add(X1);

			}

		}
//_______________________________________________________________________________________________________________________________//
		Date FIN_exection = new Date(System.currentTimeMillis());   // Relever l'heure a la fin du progamme (en// milliseconde)
																	
		Date duree = new Date(System.currentTimeMillis()); // Pour calculer la diff�rence
		duree.setTime(FIN_exection.getTime() - Debut_execution.getTime()); // Calcul de la diff�rence
		 mili = duree.getTime() % 1000;
//_______________________________________________________________________________________________________________________________//

		 Runtime rt = Runtime.getRuntime(); 
		 long mem_total = rt.totalMemory(); 
		 long mem_libre = rt.freeMemory(); 
		 // Le resultat obtenu sera en octet (byte) on le rend en Mega octet
		 //-----------------------------------------------------------------
		 mem_utilise_A = ((mem_total - mem_libre)/1024)/1024; 
		LITS=SAT.lists();
		return SAT.toString();
	}
/*********************************LES GETTERS et setter*****************************************************/
                                   /******************/		
	public ArrayList<Literale> getLITS() {
		return LITS;
	}
	public void setLITS(ArrayList<Literale> lITS) {
		LITS = lITS;
	}
	public java.util.Date getDebut_execution() {
		return Debut_execution;
	}
	public void setDebut_execution(java.util.Date debut_execution) {
		Debut_execution = debut_execution;
	}

	public static Noeud getRoot() {
		return root;
	}

	public static void setRoot(Noeud root) {
		A_etoile.root = root;
	}

	public int getNombr_clauses_SAT() {
		return Nombre_clauses_SAT;
	}

	public void setNombre_clauses_SAT(int nombre_clauses_SAT) {
		Nombre_clauses_SAT = nombre_clauses_SAT;
	}

	public long getMili() {
		return mili;
	}

	public void setMili(long mili) {
		this.mili = mili;
	}

	public long getMem_utilise_A() {
		return mem_utilise_A;
	}

	public void setMem_utilise_A(long mem_utilise_A) {
		this.mem_utilise_A = mem_utilise_A;
	}
}
