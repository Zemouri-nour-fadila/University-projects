package Partie1;

import Structure.Literale;

public class LiteraleDFS extends Literale implements Comparable<LiteraleDFS> {

    public LiteraleDFS(int getnumero, int etat, int i) {
        super(getnumero, etat, i);
    }

    @Override
    public int compareTo(LiteraleDFS o) {
        return (getnumero() - o.getnumero());
    }
}
