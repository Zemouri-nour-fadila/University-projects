package Partie1;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Stack;

import Structure.EnsembleClauses;
import Structure.Literale;
import Structure.Noeud;

public class Recherche_Profondeur {
	java.util.Date Debut_execution = new java.util.Date (System.currentTimeMillis ()); //Relever l'heure avant le debut du progamme (en milliseconde)
	private long mili;
	private long mem_utilise_DFS ;
	private int obj;
	private static Noeud root = new Noeud();// l'�l�ment racine de l'arbre
	private  int Nombre_clauses_SAT;// nombre des clause _SAT

/************************************** LES METHODES **********************************************/
                                     /***************/		
	public  String Recherche_profond(EnsembleClauses EC,int Seuil) throws InterruptedException {
		
		// Ouverte : Pile initialement vide (LIFO) :
		// -------------------------------------------
		Stack <Noeud> Ouvert = new Stack <Noeud>();
		ArrayList<Integer> NBR=new ArrayList<Integer>();
		ArrayList<Noeud> SAT_List=new ArrayList<Noeud>();
		int i = 0;//Seuil
		// 1- Initialiser la liste des clauses SAT ={vide} :
		// -----------------------------------------------
		Noeud SAT = root;// Noeud actuel	
		// 2- Empiler la racine (Literal) dans la pile Ouverte :
		// -----------------------------------------------------
		Ouvert.push(root);
		// Un litt�ral temporaire utilis� pour manipuler le litt�ral s�lectionn�
		// -----------------------------------------------------------------------
		Literale Literal_selected; 	
	    //3- v�rifier que la pile ouverte n'est pas vide (car si elle est vide on a aucun Literal � instancier) et v�rifier aussi que on a pas attaint le seuil :
	    //---------------------------------------------------------------------------------------------------------------------------------------------------
			while (i!=Seuil && !Ouvert.isEmpty()) {			
				// D�piler la pile ouverte 
				//------------------------
				SAT = Ouvert.pop();
				// Calcule le nombre de clause satisfaite pour arr�ter la recherche ou continuer
			    //-------------------------------------------------------------------------------
				Nombre_clauses_SAT = EC.Nombre_Clauses_SAT(SAT);
				NBR.add(Nombre_clauses_SAT);
				SAT_List.add(SAT);
				//V�rifier si Nmbre_Clause_SAT=nombre des clauses => nous avons trouv� une solution	pour arriter la recherche	
			   //-------------------------------------------------------------------------------------------------------------
				if (Nombre_clauses_SAT == EC.getClauses().size()) {
					Date FIN_exection = new Date (System.currentTimeMillis()); //Relever l'heure a la fin du progamme (en milliseconde) 
					Date duree = new Date (System.currentTimeMillis()); //Pour calculer la diff�rence
					duree.setTime (FIN_exection.getTime () - Debut_execution.getTime ());  //Calcul de la diff�rence
					 mili = duree.getTime () % 1000;
                   obj=Nombre_clauses_SAT;
					return SAT.toString();
				}

			// S�lectionnez le lit�ral aleatoirement :	
			//----------------------------------------
			Literal_selected = Literale. Selection_decroissante(EC.getList_Litteral(), SAT);

			// V�rifie le s�lectionn� s'il est <> null (car si il est = null alors L'instance courrant contient tout les litt�raux)
			//---------------------------------------------------------------------------------------------------------------------
				if (Literal_selected != null) {
					//6- Instancier les nouveaux litt�raux g�n�r�s avec 0 et 1( en cr�eant des noeuds) ://determiner les instanciation de Xi
					//--------------------------------------------------------------------------------
					Noeud X1 = new Noeud();
					Noeud X0 = new Noeud();
					// D�finit la profondeur des n�uds cr��s qui est �gale � la profondeur du n�ud parent + 1
					//----------------------------------------------------------------------------------------
					X1.setSeuil((short) (SAT.getSeuil() + 1));
					X0.setSeuil((short) (SAT.getSeuil() + 1));
					// cr�er un chinage avec la noeud pr�c�dent 
					//------------------------------------------
					X1.setPrecedent(SAT);
					X0.setPrecedent(SAT);
					// D�finit l'�l�ment de valeur des n�uds cr��s
					//--------------------------------------------
					X1.setLit_N(new Literale(Literal_selected.getnumero(), Literal_selected.getEtat(), 1));
					X0.setLit_N(new Literale(Literal_selected.getnumero(), Literal_selected.getEtat(), 0));                					
					// Ajoute les n�uds cr��s dans la liste d'empilement
					// ---------------------------------------------------
					Ouvert.add(X1);
					Ouvert.add(X0);
				}
				// Incr�menter le Seuil
				i++;
			}
//___________________________________________________________________________________________________________________________________________________________________________________//
			Date FIN_exection = new Date (System.currentTimeMillis()); //Relever l'heure a la fin du progamme (en milliseconde) 
			Date duree = new Date (System.currentTimeMillis()); //Pour calculer la diff�rence
			duree.setTime (FIN_exection.getTime () - Debut_execution.getTime ());  //Calcul de la diff�rence
			 mili = duree.getTime () % 1000;
//____________________________________________________________________________________________________________________________________________________________________________________//
            //Complexite spatielle 
			 Runtime rt = Runtime.getRuntime(); 
			 long mem_total = rt.totalMemory(); 
			 long mem_libre = rt.freeMemory(); 
			// Le resultat obtenu sera en octet (byte) on le rend en Mega octet
			//-----------------------------------------------------------------
			     mem_utilise_DFS = ((mem_total - mem_libre)/1024)/1024 ; 
			   	 obj = Collections.max(NBR);
			   	int index = NBR.indexOf(obj);
			   	return SAT_List.get(index).toString();
		
		}


/*********************************LES GETTERS et setter*****************************************************/
                                   /******************/	
	
public java.util.Date getDebut_execution() {
return Debut_execution;
}
public void setDebut_execution(java.util.Date debut_execution) {
Debut_execution = debut_execution;
}
public long get_tmp() {
return mili;
}
public void setMili(long mili) {
this.mili = mili;
}
public long get_sp() {
return  mem_utilise_DFS ;
}
public void setMem_utilise_DFS(long mem_utilise_DFS) {
this.mem_utilise_DFS = mem_utilise_DFS;
}
public int get_NBRCLAUSE() {
return obj;
}
public void setObj(int obj) {
this.obj = obj;
}
public static Noeud getRoot() {
return root;
}
public static void setRoot(Noeud root) {
Recherche_Profondeur.root = root;
}
public int getNombre_clauses_SAT() {
return Nombre_clauses_SAT;
}									
public void setNombre_clauses_SAT(int nombre_clauses_SAT) {
Nombre_clauses_SAT = nombre_clauses_SAT;
}	
	}


