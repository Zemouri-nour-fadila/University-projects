package Structure;

import java.util.ArrayList;

public class Clause {

// D�claration et instaciation des variables
// ------------------------------------------
	private ArrayList<Literale> Liste_Lit = new ArrayList<Literale>();
	
/*******************************  LES  CONSTRUCTEURS  ************************************/
	                            /*********************/
//1-Param�tre :vide
//-----------------
	public Clause(){}
	
//2-Param�tre : Liste des Litteraux
//---------------------------------
	public Clause(ArrayList<Literale> Liste_Lit) {
		this.Liste_Lit = Liste_Lit;
		
	}

/******************************  LES GETTERS el LES SETTERS ***********************************/
                               /****************************/

	public ArrayList<Literale> getListe_Lit() {
		return this.Liste_Lit;
	}
	public void setListe_LitL(ArrayList<Literale> Liste_Lit) {
		this.Liste_Lit = Liste_Lit;
	}
	
/******************************  LES METHODES  ***********************************/
                              /***************/	 
//___________________________________________________________________
//|                                                                   |
//|clause_nouedSAT :V�rifier que la clause est  sat  dans une arbre   | 
//|___________________________________________________________________|
 
	public int clause_nouedSAT(Noeud N) {
			int i=0;
			Literale Lit;
			while (i < Liste_Lit.size()) {
				//V�rifier si le literal existe dans l'arbre (c�d :il est instancier d�ja)
				//------------------------------------------------------------------------
				Lit = Exist_Lit_N(Liste_Lit.get(i).getnumero(), N);
				if (Lit == null)//si il n'existe pas on passe au noeud suivant
							i++;
				else {
                 //si la valeur de l'etat= la valeur de literal
					if (Liste_Lit.get(i).getEtat() == Lit.getvaleur()) {
						//on retourne 1 (clause_Sat=1) car: (etat negative : 0 = valeur 0 => inverser val_Lit = 1 )
						//(etat positive :1 = valeur 1 => val_Lit = 1 )
						return 1;                         
					} else
						i = i + 1;
						}
					}
					return 0;
}

            
//_________________________________________________________________________________________
//|                                                                                        |
//|  Exist_Lit_N :  V�rifier l'exitance d'un literal dans la sollution g�n�r�(notre Arbre) | 
//|________________________________________________________________________________________|

	public Literale Exist_Lit_N(int Num_Lit, Noeud N) {

			Noeud tmp = N;// Faire un noeud temporaire
					
           //Parcourir les npeuds 1 par 1 en v�rifiant l'existance de Literal
		  //---------------------------------------------------------------
			while (tmp.getLit_N() != null) {
				//si le literal est d�ja instancier :
				//-----------------------------------
			if (Num_Lit == tmp.getLit_N().getnumero())
				return tmp.getLit_N();//on retourne le literale
						
				//si il n'existe pas , on v�rifier son parent
                //-------------------------------------------
						tmp = tmp.get_Noeud_precedent();
			}
					return null;
}
//________________________________________________________________
//|                                                               |
//| verifier l'existance du literale dans la listes des litteraux | 
//|_______________________________________________________________|			

public Literale Existe_lit(int numero,ArrayList<Literale> Liste){
	for(Literale l: Liste) {
		if(numero == l.getnumero()) 
			return l;
	}
	return null;	
}
//________________________________________________________________________________
//|                                                                               |
//|clause_sat:calculer le nombre des clause satisfaite par une liste de litteraux | 
//|_______________________________________________________________________________|
				
public int clause_Sat(ArrayList<Literale> Liste) {
		int i;
		i = 0; 
		for(Literale l:Liste_Lit) {
			Literale tmp = Existe_lit(l.getnumero(),Liste);
			if(tmp != null && l.getEtat() == tmp.getvaleur()) {
					return 1 ;
			} else
				 i = i + 1; 
			}
					return 0;
}
//_________________________________________________________________________________________
//|                                                                                        |
//|  clause_Sat:   Calculer le nombre de clauses sat par un litteral                       | 
//|________________________________________________________________________________________|
public int clause_Sat(Literale Lit) {
		int i;
		i = 0; 
	    for(Literale lit:Liste_Lit) {
			if( lit.getEtat() == Lit.getvaleur()) {
				return 1 ;
			} else
				i = i + 1; 
			}
	return 0;
}

}

