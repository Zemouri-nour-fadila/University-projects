package Structure;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import Partie2.Chromosome;
import Partie3.Fourmis;

public class EnsembleClauses {
		
	private ArrayList<Clause> clauses = new ArrayList<Clause>();//Liste des clauses de fichier
	private ArrayList <Literale> Liste_L =new ArrayList <Literale> ();//liste des litt�raux de fichier
	int nombreVar;//nombre de literale
	int nombreClause;//nombre des clauses
	 	 
		public EnsembleClauses(String chemain) {
			// Cr�er un nouveau fichier en utilisant le fichier precis� dans le chemain :
			// --------------------------------------------------------------------------
			File file = new File(chemain);
			// D�claration et intialisation du lecteur du fichier :
			// ----------------------------------------------------
			BufferedReader br = null;
			try {
				// Commencer la lecture du fichier :
				// ---------------------------------
				br = new BufferedReader(new FileReader(file));

			} catch (FileNotFoundException ignore) {
			}					
		// D�claration et instaciation des variables
		//------------------------------------------
		int clauseSize;
		String line;
		String actualClause[];
		try {
			// On va lire le fichier , ligne par ligne, jusqu'au caract�re stop "%"
			// --------------------------------------------------------------------
			while (!(line = br.readLine()).equalsIgnoreCase("%")) {

				switch ((line = line.trim()).charAt(0)) {
				// V�rifier si la ligne repr�sente un commentaire on l'ignore
				// ----------------------------------------------------------
				case 'c':
					break;
				// V�rifier si la ligne contient le nombre des variables et des clauses on va
				// les recuper�s
				// -----------------------------------------------------------------------------------------
				case 'p': {
					this.nombreVar = Integer
							.parseInt(line.replaceAll("[^0-9 ]", "").replaceAll("  ", " ").trim().split(" ")[0]);
					this.nombreClause = Integer
							.parseInt(line.replaceAll("[^0-9 ]", "").replaceAll("  ", " ").trim().split(" ")[1]);
					break;
				}

				// V�rifier si la ligne repr�sente une clause on commence les traitements
				// -----------------------------------------------------------------------
				default: {
					// A chaque iteration on r�initialise la liste des litt�raux
					// ----------------------------------------------------------
					ArrayList<Literale> ListeLitteraux = new ArrayList<Literale>();
					// S�parer les litt�raux de la clause actuel
					// -----------------------------------------
					actualClause = line.split(" ");
					// D�finir le nombre de litt�raux par clause
					// ------------------------------------------
					clauseSize = actualClause.length;
					// Extraire les litt�raux de la clause actuelle
					// ---------------------------------------------
					for (int i = 0; i < clauseSize - 1; i++) {
						Literale x = new Literale();//cr�er un literale

						int liter = Integer.parseInt(actualClause[i]);
						if (liter < 0) {//si le literal a une forme  negative 
							liter = liter * (-1);//on garde le numero (forme positive)
							x.setnumero(liter);
							x.setvaleur(0);
							x.setEtat(0);
						} else {//sinon le literale a une forme positive 
							x.setnumero(liter);
							x.setvaleur(0);
							x.setEtat(1);
						}
						ListeLitteraux.add(x);						
					}
					// Creation de l'ensemble de clause
					// ---------------------------------
					this.clauses.add(new Clause(ListeLitteraux));
				}
				}
			}
		} catch (NumberFormatException ignore) {
		} catch (IOException ignore) {
		}
		try {			
			//Fermeture du lecteur
			//--------------------
			br.close();	
		} catch (IOException ignore) {
		}
		for (int i =1;i<=this.nombreVar;i++) {
			Liste_L.add(new Literale(i));
		}		
	}

/*********************************LES GETTERS et setter*****************************************************/
                                   /******************/

public int getNombreClause() {
return 	nombreClause;
}
public int getNombreLiteraux() {
return  nombreVar;
}
public  ArrayList<Clause> getClauses(){
return this.clauses;
}
public  ArrayList<Literale> getList_Litteral(){
return this.Liste_L;
}

public void setClauses(ArrayList<Clause> clauses) {
	this.clauses = clauses;
}
public void setListe_L(ArrayList<Literale> liste_L) {
	Liste_L = liste_L;
}
public void setNombreVar(int nombreVar) {
	this.nombreVar = nombreVar;
}
public void setNombreClause(int nombreClause) {
	this.nombreClause = nombreClause;
}

/************************************** LES METHODES **********************************************/
                                     /***************/	 
//__________________________________________________________________________	
//|                                                                         |
//| Nombre_Clauses_SAT : Calculer le nbr_clause_sat dans la solution g�n�r� | 
//|_________________________________________________________________________|

public int Nombre_Clauses_SAT(Noeud N) throws InterruptedException {
	int i = 0;
	if (N != null) {
		for (Clause clause : clauses) {
			if (clause.clause_nouedSAT(N) == 1) {
				i++;
			}
		}
	}
	return i;
}

//__________________________________________________________________________	
//|                                                                         |
//| Afficher les clauses de notre probleme SAT                              | 
//|_________________________________________________________________________|
public String toString() {
	String s = "La liste des clauses est : \n";
	for (int i = 0; i < this.clauses.size(); i++) {
		String Cls = clauses.get(i).toString();
		s = "C" + i + "=" + Cls + "\n";
		System.out.println("C" + i + "=" + Cls);
	}
	return s;
}
//__________________________________________________________________________	
//|                                                                         |
//| Nombre_Clauses_SAT : Calculer le nbr_clause_sat par le chromosome       | 
//|_________________________________________________________________________|
public short Nombre_Clauses_SAT(Chromosome ch) throws InterruptedException {
	short i = 0;
	if (ch.getListe_Lit() != null) {
		for (Clause clause : clauses) {			
			if (clause.clause_Sat(ch.getListe_Lit()) == 1) {
				i++;
			}
		}
	}
	return i;
}
//__________________________________________________________________________________	
//|                                                                                 |
//|verification du nombre de clause satisfait par une soll construit par une fourmis| 
//|_________________________________________________________________________________|

public Integer Nombre_Clauses_SAT(Fourmis s) throws InterruptedException {
	Integer i = 0;
	if (s.getListe_Lit() != null) {
		for (Clause clause : clauses) {			
			if (clause.clause_Sat(s.getListe_Lit()) == 1) {
				i++;
			}
		}
	}
	return i;
}
//__________________________________________________________________________________	
//|                                                                                 |
//|verification du nombre de clause satisfait par un literale                       | 
//|_________________________________________________________________________________|
public int  Nombre_Clauses_SAT(Literale Lit) throws InterruptedException {
	short i = 0;
	if(Lit != null) {
        for (Clause clause : clauses) {
            if (clause.clause_Sat(Lit) == 1) {
            	i++;	 
            }}}
            
    return i;
}
}