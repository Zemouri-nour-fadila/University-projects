package Structure;

import java.util.ArrayList;

public class Noeud {
	
	private Noeud precedent = null;//Le parent du Noeud
	private Literale Lit_N = null;//Le literale du noeud 
	private short Seuil = 0;// le Seuil du Noeud dans l'arbre
	private ArrayList<Literale> lits = new ArrayList<Literale>();
	
//1- constructeur vide 
//-----------------
	public Noeud() {}
/******************************  LES GETTERS et LES SETTERS  ***********************************/
                              /*****************************/
	public Noeud get_Noeud_precedent() {
		return precedent;
	}
	public short getSeuil() {
		return Seuil;
	}
	public Literale getLit_N() {
		return Lit_N;
	}
	public void setPrecedent(Noeud precedent) {
		this.precedent = precedent;
	}
	public void setLit_N(Literale Lit_N) {
		this.Lit_N = Lit_N;
	}
	public void setSeuil(short Seuil) {
		this.Seuil = Seuil;
	}
/*****************************  LES METHODES *********************************************************/
                              /***************/	
//_________________________________________________________________________	
//|                                                                        |
//| lists:permet de recuperer la liste des literale generer dans une arbre | 
//|________________________________________________________________________|
	public ArrayList<Literale> lists() {
		String n_SAT = "";
		Noeud N_SAT = this;
		while (N_SAT.getLit_N() != null) {
			lits.add(N_SAT.getLit_N());
			N_SAT = N_SAT.precedent;
		}
		return lits;
	}
//____________________________________________________________________________________________________	
//|                                                                                                   |
//|Afficher la solution trouv� qui contients  les instanciations des litt�raux de la solution g�n�r�  | 
//|___________________________________________________________________________________________________|
		
		public String toString() {
			String n_SAT = "";
			Noeud N_SAT = this;
			while (N_SAT.getLit_N() != null) {
				n_SAT += N_SAT.getLit_N().getnumero() + "=" + N_SAT.getLit_N().getvaleur() + " ";
				N_SAT = N_SAT.precedent;
			}
			return "La solution trouv�  : { " + n_SAT + "}";
		}

	
}
