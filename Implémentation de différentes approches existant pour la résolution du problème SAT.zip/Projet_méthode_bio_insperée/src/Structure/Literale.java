package Structure;

import java.util.ArrayList;

public class Literale {

	// D�claration de variables
	// -------------------------
	private int numero; // Le num�ro de lit�rale
	private int valeur; // La valeur de lit�rale (0 ou 1 ou -1)
	private int Etat;   // Litt�rale positif = 1 n�gatif = 0

	/************************************** Lites contructeurs*********************************/
	                                        /*****************/

	public Literale() {
	}

//1-Param�tre : Num_Lit et Etat (0 ou 1) pour Lite signe de Literal et Lit a vaLeur instanci�e 
//--------------------------------------------------------------------------------------------
	public Literale(int numero, int Etat, int valeur) {
		super();
		this.Etat = Etat;
		this.valeur = valeur;
		this.numero = numero;
	}

//2-Param�tre : objet Litt�raLit
//------------------------------	
	public Literale(Literale l) {
		this.numero = l.numero;
		this.valeur = l.valeur;
		this.Etat = l.Etat;

	}

//3-Param�tre : Num_Lit et Etat (0 ou 1) pour Lite signe de Literal  
//------------------------------------------------------------------	
	public Literale(int numero, int valeur) {
		this.numero = numero;
		this.valeur = valeur;

	}
//4-Constructors
	public Literale(int numero) {
		super();
		this.numero = numero;
	}

	/************************************** Lites des Getters et Setters***********************************/
	                                      /*****************************/


	public int getvaleur() {
		return this.valeur;
	}

	public int getnumero() {
		return this.numero;
	}

	public int getEtat() {
		return this.Etat;
	}

	public void setnumero(int numero) {
		this.numero = numero;
	}

	public void setEtat(int Etat) {
		this.Etat = Etat;
	}

	public void setvaleur(int valeur) {
		this.valeur = valeur;
	}

	/****************************** LES METHODES*******************************************/
	                              /***************/

//  __________________________________________________________________________	 
// |                                                                          |
// |    Exist_Lit : V�rifier l'existance du literal courrant dans le noeud    | 
// |__________________________________________________________________________|

	private static boolean Exist_Lit(Noeud i, Literale Lit) {
		Noeud tmp = i;// cr�er une instance pour ne pas modifer le noeud original

		while (tmp.getLit_N() != null) {// parcourir les noeuds 1 par 1

			// Si le Literal r�cup�r� est le meme que le literal envoy� en parametre
			// -----------------------------------------------------------------------
			if (Lit.getnumero() == tmp.getLit_N().getnumero()) {
				return true;
			} else
				tmp = tmp.get_Noeud_precedent();

		}
		return false;
	}

// ________________________________________________________________________________________
// |                                                                                       |
// | Selection_decroissante : G�n�rer Num_Lit dans l'ordre d�croissant                     |
// |_______________________________________________________________________________________|

	public static Literale Selection_decroissante(ArrayList<Literale> List_Lit, Noeud N) {

		// 1-SeLitectionner Le Literal seLon son nbr d'apparaition dans Les Clauses
		// ---------------------------------------------------------------------------
		for (int i = 0; i < List_Lit.size(); i++) {// parcourir liste_lit
			// 2-V�rifier si ce literal(i) exist dans N
			// ------------------------------------------
			if (!Exist_Lit(N, List_Lit.get(i))) {

				return new Literale(List_Lit.get(i));
			}

		}
		return null;
	}
//	_____________________________________________________________________________________
// |                                                                                     |
// | Calcule_heuristique : Calculer le nombre d'appartion de literal dans les Clauses    | 
// |_____________________________________________________________________________________|

	public static int Calcule_heuristique(Literale Lit, ArrayList<Clause> C) {
		int nbr_C = 0; // n'existe pas dans la clause
		for (Clause clause : C)
			// V�rifier l'existance de Lit si oui on incr�mente le nbr_Lit
			// -----------------------------------------------------------
			if (clause.getListe_Lit().contains(Lit))
				nbr_C++;
		return nbr_C;
	}
//	____________________________________________________________________________
// |                                                                            |
// | Calcule_Cout : Calculer le nombre de clauses satisfaite par le literal     | 
// |____________________________________________________________________________|
	public static int[] Calcule_Cout(EnsembleClauses EC, Noeud noeud) throws InterruptedException {

		//Declaration et initialisation des variable
		//------------------------------------------
		int nbr_clause_sat_max = 0;
		int valeur = -1;
		int[] arr = new int[2];

		//Pour un literale on lui donne 0 ou 1
		//------------------------------------
		for (int k = 0; k < 2; k++) {

			int nbr_clause_sat = 0;

			if (k == 0) {
				noeud.getLit_N().setvaleur(0);
				nbr_clause_sat = EC.Nombre_Clauses_SAT(noeud);

			} else {
				noeud.getLit_N().setvaleur(1);
				nbr_clause_sat = EC.Nombre_Clauses_SAT(noeud);

			}
			// Prendre la valeur du litterale qui maximise le nombre des clauses satisfaite
			//-----------------------------------------------------------------------------
			if (nbr_clause_sat_max < nbr_clause_sat) {
				nbr_clause_sat_max = nbr_clause_sat;
				valeur = noeud.getLit_N().getvaleur();
			}
		}
		
		arr[0] = nbr_clause_sat_max;
		arr[1] = valeur;

		return arr;

	}

//  __________________________________________________________________________	 
// |                                                                          |
// | SeLitect_Lit :r�cup�rer Num_Lit qui a la meilleure val de fitnesse      | 
// |__________________________________________________________________________|

	public static Literale SeLect_Lit(EnsembleClauses EC, Noeud n) throws InterruptedException {

		int NUM_Lit = -1;// Position de literal(cas existe dans la clause)
		int Max = -1;// Lit n'existe dans aucune clause
		Noeud noeud = new Noeud();

		// 1-SeLitectionner Le Literal seLon son nbr d'apparaition dans Les Clauses
		// ---------------------------------------------------------------------------
		for (int i = 0; i < EC.getList_Litteral().size(); i++) {// parcourir liste_lit

			// 2-V�rifier si ce literal(i) exist dans InT
			// ------------------------------------------
			if (!Exist_Lit(n, EC.getList_Litteral().get(i))) {

				// 3-Calculer nombre des clauses qui contient le literal
				// -----------------------------------------------------
				int h = Calcule_heuristique(EC.getList_Litteral().get(i), EC.getClauses());

				noeud.setPrecedent(n);
				noeud.setLit_N(EC.getList_Litteral().get(i));
				// 4-Calculer combient de clauses que satisfait le literale
				// --------------------------------------------------------
				int g = Calcule_Cout(EC, noeud)[0];

				int f = h + g;
				if (f >= Max) {
					Max = f;     // Mettre � jours le Max
					NUM_Lit = i; // R�cup�rer la position de literal(i)
				}
			}
		}
		if (NUM_Lit != -1) {// Si le literal existe on le r�cup�re
			int l = Calcule_Cout(EC, noeud)[1];
			Literale Lit = new Literale(EC.getList_Litteral().get(NUM_Lit).getnumero(), l);

			return Lit;
		}
		return null;
	}

	

}
