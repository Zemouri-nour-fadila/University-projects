package Partie2;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import Structure.EnsembleClauses;

public class Recherche_GA {
	java.util.Date Debut_execution = new java.util.Date (System.currentTimeMillis ()); //Relever l'heure avant le debut du progamme (en milliseconde)
	private long mili;
	private long mem_utilise_GA ;
	int Taille_pop; // Taille_population
	int Max_itter; // nbr_itteration
	float P_croisement;// Taux croisement
	float P_mutation; // Taux de mutation
	private EnsembleClauses EC;
	private  int nbr_SAT = 0;// nbr clause sat
	private  int nbr_SATG = 0;
	int k;
	int pas_damelioration;
/******************** Constructeur *******************************/
                     /************/
public Recherche_GA(int sizePop, int Max_itter, float P_croisement, float P_mutation, EnsembleClauses EC) {
		this.Taille_pop = sizePop;
		this.Max_itter = Max_itter;
		this.P_croisement = P_croisement;
		this.P_mutation = P_mutation;
		this.EC = EC;
}
/****************les methodes***********************************/
                /***********/
	public String GA(int k_point) throws InterruptedException {
		 Runtime rt = Runtime.getRuntime(); 
		 long mem_total = rt.totalMemory(); 
		 int nbr = EC.getNombreLiteraux();
		 Population p = new Population(Taille_pop);//Generation de la population 
		 p.Inisialisation_Pop_Aleatoire(EC);// initialization de la solution
		 ArrayList<Chromosome> Enfants;// Stocker les enfants g�n�rer
         //pour manipuler l'enfant
		  Chromosome tmp = null;
		  int iter = 0;
		  while (iter < Max_itter && pas_damelioration!=10) {			
			ArrayList<Float> prob_Chromosome = new ArrayList<Float>(); // Calculer la probabilit�
			prob_Chromosome = p.evaluation_population();
			// Selection par roulette
			// ----------------------
			ArrayList<Chromosome> Chromosomes = p.selection_roulette(prob_Chromosome);
			for (int i = 0; i < Chromosomes.size() - 1; i++) {
				// Gen�ration des enfants
				// ------------------------
				Enfants = p.Croisement(Chromosomes.get(i), Chromosomes.get(i + 1), k_point);
				for (Chromosome Enfant : Enfants) {
					// Mutation selon la valeur al�atoire g�n�r� (oui/non)
					//-----------------------------------------------------
					Random r = new Random();
					float prob = r.nextFloat();
					// Comparer entre la probabilit� trouv� aleatoirement et le taux de mutation
					//---------------------------------------------------------------------------
					if (prob < P_mutation) {
						p.Mutation(Enfant);
					}					
					nbr_SAT = EC.Nombre_Clauses_SAT(Enfant);
					Enfant.setFitness(nbr_SAT);
				}
				// Ins�rer les enfants dans la population
				//---------------------------------------
				p.Insertion(Enfants);
				Collections.sort(p.getChromosomes(),Collections.reverseOrder());
			}
			//evaluation des enfants et selection de la meilleur solution 
			//-----------------------------------------------------------
				tmp = p.getChromosomes().get(0);
				nbr_SAT=tmp.getFitness();
				if (nbr_SAT >= nbr_SATG) {
					nbr_SATG = nbr_SAT;
				} else {
					pas_damelioration++;
				}
				if (nbr_SAT == EC.getNombreClause()) {
					Date FIN_exection = new Date (System.currentTimeMillis()); //Relever l'heure a la fin du progamme (en milliseconde) 
					Date duree = new Date (System.currentTimeMillis()); //Pour calculer la diff�rence
					duree.setTime (FIN_exection.getTime () - Debut_execution.getTime ());  //Calcul de la diff�rence
					 mili = duree.getTime () % 1000;
					return  tmp.toString();
				}
				iter++;
			}
		Date FIN_exection = new Date (System.currentTimeMillis()); //Relever l'heure a la fin du progamme (en milliseconde) 
		Date duree = new Date (System.currentTimeMillis()); //Pour calculer la diff�rence
		duree.setTime (FIN_exection.getTime () - Debut_execution.getTime ());  //Calcul de la diff�rence	
        //Complexite spatielle 
		//--------------------
		 long mem_libre = rt.freeMemory(); 
		 mili = duree.getTime () % 1000;
	     mem_utilise_GA = ((mem_total - mem_libre)/1024)/1024 ; 
		return tmp.toString() ;
	}
	

/***************GETTERS et SETTERS **********************************/
	          /*******************/
	public int getTaille_pop() {
		return Taille_pop;
	}

	public void setTaille_pop(int taille_pop) {
		Taille_pop = taille_pop;
	}

	public int getMax_itter() {
		return Max_itter;
	}

	public void setMax_itter(int max_itter) {
		Max_itter = max_itter;
	}

	public float getP_croisement() {
		return P_croisement;
	}

	public void setP_croisement(float p_croisement) {
		P_croisement = p_croisement;
	}

	public float getP_mutation() {
		return P_mutation;
	}

	public void setP_mutation(float p_mutation) {
		P_mutation = p_mutation;
	}

	public EnsembleClauses getEC() {
		return EC;
	}

	public void setEC(EnsembleClauses eC) {
		EC = eC;
	}

	public int getNbr_SAT() {
		return nbr_SAT;
	}

	public void setNbr_SAT(int nbr_SAT) {
		this.nbr_SAT = nbr_SAT;
	}

	public int getNbr_SATG() {
		return nbr_SATG;
	}

	public void setNbr_SATG(int nbr_SATG) {
		this.nbr_SATG = nbr_SATG;
	}

	public int getK() {
		return k;
	}

	public void setK(int k) {
		this.k = k;
	}

	public int getPas_damelioration() {
		return pas_damelioration;
	}

	public void setPas_damelioration(int pas_damelioration) {
		this.pas_damelioration = pas_damelioration;
	}
	public long getMili() {
		return mili;
	}

	public void setMili(long mili) {
		this.mili = mili;
	}
	public void setMem_utilise_GA(long mem_utilise_DFS) {
		this.mem_utilise_GA = mem_utilise_DFS;
	}
	public long getMem_utilise_GA() {
		return mem_utilise_GA;
	}
}
