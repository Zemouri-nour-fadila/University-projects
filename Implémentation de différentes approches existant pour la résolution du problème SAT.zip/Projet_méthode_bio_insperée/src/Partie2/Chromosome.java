package Partie2;

import java.util.ArrayList;
import java.util.Random;

import Structure.Literale;

public class Chromosome implements Comparable<Chromosome> {
	
    //ensemble des g�nes 
	//------------------
	private ArrayList<Literale> list_lit = new ArrayList<Literale>();
	private int Fitness;
	
/*************************************Constructeurs*********************************/
	                               /*****************/
	public Chromosome() {}
/********************************GETTERS et SETTERS ******************************/	
	                            /*******************/	
	public ArrayList<Literale> getListe_Lit() {
		return list_lit;
		} 	
	public int getFitness() {
		return Fitness ;
		}
public void setListe_Lit(ArrayList<Literale> liste_Lit) {
	this.list_lit = liste_Lit;
}
public void setFitness(int f) {
	this.Fitness = f;
}
/*******************************METHIDES****************************************/
                               /**********/
//_______________________________________
//|                                      |
//| generation aleatoire d'un chromosome | 
//|______________________________________|

public ArrayList<Literale> Init_chro_aleatoire(ArrayList<Literale> liste_lit) {
		for (int i=0 ;i<liste_lit.size();i++) {
			Random r = new Random();
			this.list_lit.add(new Literale(i+1, r.nextInt(2)));
		}
		return this.list_lit;
	}
//_______________________________________
//|                                      |
//| croisement k-points                  | 
//|______________________________________|
	public ArrayList<Chromosome> K_point(Chromosome Chromosome, int K) {
		int point_1;
		int point_2;
		ArrayList<Chromosome> Chromosomes;
		 if (K==1) {
			    Random r = new Random();
				int point = r.nextInt(list_lit.size());
				return Inverser_parent(this, Chromosome, point);
		 }
		Random r=new Random();
		point_1 = r.nextInt(list_lit.size());
		Chromosomes=Inverser_parent(this,Chromosome,point_1);
		for(int i=1;i<K;i++) {
			int j=list_lit.size()-point_1;
			point_2 = r.nextInt(j);
			point_2=point_1 + point_2;
			Chromosomes=Inverser_parent(Chromosomes.get(0),Chromosomes.get(1),point_2);
			point_1=point_2;
		}
		return Chromosomes;
	}
//_______________________________________
//|                                      |
//| croisement :generation des enfants   | 
//|______________________________________|

	public ArrayList<Chromosome> Inverser_parent(Chromosome Chromosome_1, Chromosome Chromosome_2, int index) {
		ArrayList<Chromosome> Chromosomes = new ArrayList<Chromosome>();
		Chromosomes.add(new Chromosome());
		Chromosomes.add(new Chromosome());
		for (int i = 0; i < list_lit.size(); i++) {
			if (i < index) {
				Chromosomes.get(0).list_lit.add(new Literale(Chromosome_1.getListe_Lit().get(i)));
				Chromosomes.get(1).list_lit.add(new Literale(Chromosome_2.getListe_Lit().get(i)));
			} else {
				Chromosomes.get(1).list_lit.add(new Literale(Chromosome_1.getListe_Lit().get(i)));
				Chromosomes.get(0).list_lit.add(new Literale(Chromosome_2.getListe_Lit().get(i)));
			}
		}
		return Chromosomes;
	}

//________________________________________________________________
//|                                                               |
//| comparaison pour tie la listes des chromosome selon fitness   | 
//|_______________________________________________________________|
	@Override
	public int compareTo(Chromosome chromosome) {
		// TODO Auto-generated method stub
		return (this.Fitness - chromosome.Fitness);
	}
//________________________________________________________________
//|                                                               |
//| tostring:afficher chromosome                                  | 
//|_______________________________________________________________|
		public String toString() {
			String SAT_solution = "";
			for (Literale l : list_lit)
				SAT_solution += l.getnumero() + "=" +l.getvaleur() + " ";
			return "Solution : [" + SAT_solution + "]";
		}
}
