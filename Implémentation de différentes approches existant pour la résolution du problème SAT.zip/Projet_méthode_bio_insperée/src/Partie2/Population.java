package Partie2;

import java.util.ArrayList;
import java.util.Random;

import Structure.EnsembleClauses;
import Structure.Literale;

public class Population {
	
	private ArrayList<Chromosome> Chromosomes;// Liste des individus
	private int Taille;// la taille de la population
/******************** Constructeur *******************************/
	                  /************/
public Population( int Taille) {
	this.Taille = Taille;
	Chromosomes = new ArrayList<Chromosome>(Taille);
}
/****************les methodes***********************************/
                 /***********/
//________________________________________________	
//|                                               |
//| initialisation de la population al�atoirement | 
//|_______________________________________________|
	public void Inisialisation_Pop_Aleatoire(EnsembleClauses EC) throws InterruptedException {
		Chromosome chromosome;
		ArrayList<Literale>liste_Lit;
		for (int i = 0; i < Taille; i++) {
			chromosome = new Chromosome();
			liste_Lit = chromosome.Init_chro_aleatoire(EC.getList_Litteral());
			chromosome.setListe_Lit(liste_Lit);
			int f= EC.Nombre_Clauses_SAT(chromosome);
			chromosome.setFitness(f);
			Chromosomes.add(chromosome);
		}
	}
//________________________________________________	
//|                                               |
//| Selection des individu                        | 
//|_______________________________________________|   
	public ArrayList <Float> evaluation_population() throws InterruptedException{
		ArrayList <Integer> fitnes_Chromosomes = new ArrayList<Integer>();
		ArrayList <Float> prob_Chromosomes = new ArrayList<Float>();
        int somme_fitness=0;
		//calculer  total de fitness
        //--------------------------
			somme_fitness=Somme_Fitness();
		//calcule de la valeur du prob pour chaque Chromosome
		//----------------------------------------------------
		for(int i=0 ; i<Taille;i++){
			//prendre deux nombre apres la virgule 
			//-------------------------------------
			float p1=(float)Math.round((float)(getChromosomes().get(i).getFitness()*100)/somme_fitness*100)/100;	
			prob_Chromosomes.add (p1);
		}
		return prob_Chromosomes;
	}
//________________________________________________	
//|                                               |
//| calculer total de fitness                     | 
//|_______________________________________________| 	
	public int Somme_Fitness() {
		int somme_fitness = 0;
		for (int i = 0; i < Taille; i++) {
			int fitness = this.getChromosomes().get(i).getFitness();
			somme_fitness = somme_fitness + fitness;
		}
		return somme_fitness;
	}
//________________________________________________	
//|                                               |
//|SELECTION PAR ROULETTE                         | 
//|_______________________________________________| 	
	public ArrayList<Chromosome> selection_roulette(ArrayList <Float> prob_Chromosomes) {
		float inter[ ] ;
		ArrayList <float []> intervals_prob = new ArrayList<float []>();
		//attribuer un intervalle pour chaque Chromosomes
		//------------------------------------------------
		for(int i=0 ; i<Taille;i++){
			   inter=new float[2];
			   if(i==0) {inter[0]=0;}
			   else     {inter[0]=intervals_prob.get(i-1)[1];   }
		
					     inter[1]=inter[0]+prob_Chromosomes.get(i);		
					     intervals_prob.add(inter);			
		}	
		//tourner la roue  n/2 fois =>n:taille de la population
		//-----------------------------------------------------		
		int nbr_selection=(int)(Taille/2);
		ArrayList<Chromosome> parents_selectionn�e=new ArrayList<Chromosome>();
		Random random = new Random();
        int nb;
		for(int j=0 ;j<nbr_selection;j++){
			nb = random.nextInt(100);
			for(int i=0 ; i<Taille;i++){
				 if(nb>intervals_prob.get(i)[0] && nb<=intervals_prob.get(i)[1]) {				
					 parents_selectionn�e.add(Chromosomes.get(i));
				 }
			}			
		}
		return parents_selectionn�e;
	}
//________________________________________________	
//|                                               |
//|Croisement                                     | 
//|_______________________________________________| 
 public ArrayList<Chromosome> Croisement(Chromosome Chromosome_1, Chromosome Chromosome_2, int kCross) {
	 return Chromosome_1.K_point(Chromosome_2, kCross);
}
// _______________________________________________	
//|                                               |
//|mutation                                       | 
//|_______________________________________________| 
	public void Mutation(Chromosome Chromosome) {
		Random r = new Random();
		int random_point = r.nextInt(Chromosome.getListe_Lit().size());
		Chromosome.getListe_Lit().get(random_point).setvaleur(Chromosome.getListe_Lit().get(random_point).getvaleur() == 0 ? 1 : 0);
	}
// __________________________________________________	
//|                                                  |
//|Inserer les chromosomes  dans la population actuel| 
//|__________________________________________________| 
	public void Insertion(ArrayList<Chromosome> chromosomes) {
		for (int i =0;i<chromosomes.size();i++)
			Chromosomes.add(chromosomes.get(i));
	}

/***************GETTERS et SETTERS **********************************/
	          /*******************/
	
	public ArrayList<Chromosome> getChromosomes() {
		return Chromosomes;
	}
	public void setChromosomes(ArrayList<Chromosome> Chromosomes) {
		this.Chromosomes = Chromosomes;
	}
	public int getTaille() {
		return Taille;
	}
	public void setTaille(int taille) {
		Taille = taille;
	}
	

	
}