
public enum TypePackage {
	Standard,
	Premium
}
