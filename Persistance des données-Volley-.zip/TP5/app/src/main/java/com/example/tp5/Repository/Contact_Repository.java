package com.example.tp5.Repository;

import android.app.Application;
import android.util.Log;

import androidx.lifecycle.MutableLiveData;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;

import com.example.tp5.Bdd.MyRequestQue;

import com.example.tp5.Entity.Contact;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class Contact_Repository {

    //en cas ou le viewModel souhaite recuperer le liste des contacts
    MutableLiveData<List<Contact>> myList;
    //Constructeur
    //application non context (context c'est faut)
    public Contact_Repository(Application application){
        //Recuperer les donnees du web server
        myList= getMyList(application);
    }

    public MutableLiveData<List<Contact>> getMyList(Application application) {
        // 1- Recuperer requestQue
        //MyRequestQue.getInstance(application);

        // 2- Creer la requete
        MutableLiveData<List<Contact>> ListMutableLiveData = new MutableLiveData<List<Contact>>();
        //cmd -> ipconfig -> 192.168.1.40
        String url="http://192.168.1.40//getMycontact.php";
        JsonArrayRequest myRequest= new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                //Ajouter le contact dans la liste des contacts (myList)
                List<Contact> temp=new ArrayList<>();
                for(int i=0;i< response.length();i++){

                    Contact c=new Contact();
                    try {
                        // Recuperer les contacts dans array par indice
                        JSONObject jsonObject= response.getJSONObject(i);
                        c.setNom(jsonObject.getString("nom"));
                        c.setTel(jsonObject.getString("numero"));
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    temp.add(c);
                    ListMutableLiveData.setValue(temp);
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("error",error.getMessage());
            }
        });

        // 3- ajouter la requete dans la file
        MyRequestQue.getInstance(application).ajouterAlaQue(myRequest);

        return ListMutableLiveData;
    }



}
