package com.example.tp5.Bdd;

import android.content.Context;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;

public class MyRequestQue {


    //Singleton
    private static MyRequestQue INSTANCE;
    private RequestQueue nRequestQue;
    Context context;

    //Constructeur
    private MyRequestQue(Context context){
        //recuperer context
        this.context=context;
        nRequestQue=getnRequestQue();


    }


    public static MyRequestQue getInstance(Context context){
        if(INSTANCE ==null){
            INSTANCE=new MyRequestQue(context);
        }
        return INSTANCE;
    }


    public RequestQueue getnRequestQue() {
        if(nRequestQue==null){
            nRequestQue=Volley.newRequestQueue(context);
        }
        return nRequestQue;
    }

    public void ajouterAlaQue(Request r){
        nRequestQue.add(r);
    }
}
