package com.example.tp5.ViewModel;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.tp5.Entity.Contact;
import com.example.tp5.Repository.Contact_Repository;

import java.util.List;


public class Contact_ViewModel extends AndroidViewModel{

    Contact_Repository mContactRepository;
    MutableLiveData<List<Contact>> mListContact;


    //remove @NonNull
    public Contact_ViewModel(Application application) {
        super(application);
        mContactRepository = new Contact_Repository(application);
        mListContact = mContactRepository.getMyList(application);
    }

    //mettre a jour la liste
    public LiveData<List<Contact>> getMyListContact(){
        mListContact = mContactRepository.getMyList(getApplication());
        return mListContact;
    }


}
