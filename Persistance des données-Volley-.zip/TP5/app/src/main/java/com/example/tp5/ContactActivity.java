package com.example.tp5;

import android.os.Bundle;

import com.example.tp5.Entity.Contact;
import com.example.tp5.ViewModel.Contact_ViewModel;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;

import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tp5.databinding.ActivityContactBinding;

import java.util.List;

public class ContactActivity extends AppCompatActivity {


    private ActivityContactBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //recupere activity_content.xml
        binding = ActivityContactBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);


        // Inialisation de RecycleView
        //Recuperer le id de recycler view dans content_contact qui ce trouve dans activity_contact -> getRoot()
        RecyclerView recyclerView = binding.getRoot().findViewById(R.id.rv_contact);
        //Affichage de recycler view
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Inialisation de ViewModel
        //Recuperer la liste de contact dans la bdd
        Contact_ViewModel contactViewModel = new ViewModelProvider(this).get(Contact_ViewModel.class);



        //Creation d'un Adapteur
        AdapteurContact adapteurContact=new AdapteurContact(this,null);

        //Lier adapteur aux recyclerView
        recyclerView.setAdapter(adapteurContact);

        //Liée adapteur a la liste des contact
        //L'adpteur va observer la listes des contats en utilisant LiveData
        //Si les donnees changent dans la bdd livedata notify l'apteur qui notify le RecyclerView
        contactViewModel.getMyListContact().observe(this, new Observer<List<Contact>>() {
            @Override
            public void onChanged(List<Contact> contacts) {
                adapteurContact.setmList(contacts);
            }
        });

        //Bouton qui flote
        binding.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //On cliquant sur ce bouton on va ce rediriger vers la classe addcontactactivity.java

            }
        });
    }


}