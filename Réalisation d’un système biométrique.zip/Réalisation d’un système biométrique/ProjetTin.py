# -*- coding: utf-8 -*-
"""
Created on Thu Feb 18 09:08:02 2021

@author: Amina
"""
from tkinter.messagebox import *
from tkinter.filedialog import *
from tkinter import filedialog 
from tkinter import *
from tkinter import ttk 
from PIL import Image ,ImageTk
import numpy as np 
import cv2
from os import listdir
from os.path import isfile, join


def openfilename(): 
  
    filename = filedialog.askopenfilename(title ='Veuillez inserer une image') 
    return filename 

def open_img(): 
    
    #Effacer le contenu des resultat des etapes precedante  
    for widget in frame.winfo_children():
          widget.destroy()
    #Effacer le contenu du sift etape precedante  
    for widget in l3.winfo_children():
          widget.destroy()
    #Effacer le contenu de la decission precedante     
    for widget in l1.winfo_children():
          widget.destroy()
    
    x = openfilename() 
    img = Image.open(x)
    
    #Zone de traitement de l'image requete
    panel=Label(frame,text="Egalisation d'histogramme ",fg="#677eaa",font=("courrier",15))
    panel.pack()
    img=Egaliastion_histogramme(img)# Egaliastion de histogramme
    #supprimer les <widget> 
    
    img_trai = ImageTk.PhotoImage(img)
    panel=Label(frame,image=img_trai)
    panel.image = img_trai
    panel.pack() 
    
    
    #lissage de l'image 
    panel=Label(frame,text="Lissage Medean",fg="#677eaa",font=("courrier",15))
    panel.pack()
    img=lissage_image(img)          
    img_trai1 = ImageTk.PhotoImage(img)
    panel=Label(frame,image=img_trai1)
    panel.image = img_trai1
    panel.pack()
    
    
    # Amelioration du contraste 
    panel=Label(frame,text="Amélioration du contraste",fg="#677eaa",font=("courrier",15))
    panel.pack()
    img=Amelioration_contraste(img)          
    img_trai = ImageTk.PhotoImage(img)
    panel=Label(frame,image=img_trai)
    panel.image = img_trai
    panel.pack()
    
    
    
    
    
    """
    #segmentation de l'image 
    panel=Label(frame,text="Ségmentation ",fg="#677eaa",font=("courrier",15))
    panel.pack()
    img=Segmentation_avec_clusstering(img)         
    img_trai = ImageTk.PhotoImage(img)
    panel=Label(frame,image=img_trai)
    panel.image = img_trai
    panel.pack()
    """
    
    
    #Zone de mise en corespondance de l'image requete
    img=detecteur_discripteur_SIFT(img)
    img = ImageTk.PhotoImage(img)
    panel=Label(l3,image=img)
    panel.image = img
    panel.pack() 
    
    
    
def converged(centroids, old_centroids):
	if len(old_centroids) == 0:
		return False
	if len(centroids) <= 5:
		a = 1
	elif len(centroids) <= 10:
		a = 2
	else:
		a = 4
	for i in range(0, len(centroids)):
		cent = centroids[i]
		old_cent = old_centroids[i]

		if ((int(old_cent[0]) - a) <= cent[0] <= (int(old_cent[0]) + a)) and ((int(old_cent[1]) - a) <= cent[1] <= (int(old_cent[1]) + a)) and ((int(old_cent[2]) - a) <= cent[2] <= (int(old_cent[2]) + a)):
			continue
		else:
			return False
	return True


def getMin(pixel, centroids):
	minDist = 9999
	minIndex = 0
	for i in range(0, len(centroids)):
		d = np.sqrt(int((centroids[i][0] - pixel[0]))**2 + int((centroids[i][1] - pixel[1]))**2 + int((centroids[i][2] - pixel[2]))**2)
		if d < minDist:
			minDist = d
			minIndex = i
	return minIndex


def assignPixels(centroids,img_width, img_height,px):
	clusters = {}
	for x in range(0, img_width):
		for y in range(0, img_height):
			p = px[x, y]
			minIndex = getMin(px[x, y], centroids)
			try:
				clusters[minIndex].append(p)
			except KeyError:
				clusters[minIndex] = [p]
	return clusters


def adjustCentroids(centroids, clusters):
	new_centroids = []
	keys = sorted(clusters.keys())
	for k in keys:
		n = np.mean(clusters[k], axis=0)
		new = (int(n[0]), int(n[1]), int(n[2]))
		new_centroids.append(new)
	return new_centroids

def startKmeans(someK,img_width,img_height,px):
	centroids = []
	old_centroids = []
	i = 1
	for k in range(0, someK):
		cent = px[np.random.randint(0, img_width), np.random.randint(0, img_height)]
		centroids.append(cent)
	while not converged(centroids, old_centroids) and i <= 20:
		i += 1
		old_centroids = centroids 								
		clusters = assignPixels(centroids,img_width,img_height,px) 						
		centroids = adjustCentroids(old_centroids, clusters) 	
	return centroids
    
def Remplissage(I):
  n=I.shape[0] #lines numbers
  m=I.shape[1] #columns numbers

  collone1=np.array([I[:,0]]).T
  collone2=np.array([I[:,m-1]]).T
  
  I= np.c_[collone1,I,collone2]#ajout des 2 collones
  
  ligne1=np.array([I[0,:]])
  ligne2=np.array([I[n-1,:]])

  I= np.r_[ligne1,I,ligne2]    #ajout des 2 lignes
  
  return I
def Conversion(I):
    
  I_convert=I
  for i in range (0,I.shape[0],1) :
    for j in range (0,I.shape[1],1) :
      
      if I[i][j] >= 129 :
         I_convert[i][j] = 255
      else :
         I_convert[i][j] = 0
  return I_convert   

def Trim(I):
  I=np.delete(I, 0, axis = 1)
  I=np.delete(I, I.shape[1]-1, axis = 1)
  I=np.delete(I, 0, axis = 0)
  I=np.delete(I, I.shape[0]-1, axis = 0)
  return I


def Dilatation(I,F):
  n=I.shape[0] #lines numbers
  m=I.shape[1] #columns numbers
  cst=1
  #create the new matrix of the smoothed image
  I_dilate=np.ones([n,m]) 
  for i in range(cst, n-cst):
   for j in range(cst,m-cst):
     temp= I[i-cst:i+cst+1, j-cst:j+cst+1]
     product= temp*F
     I_dilate[i][j]= np.max(product)
  return I_dilate

def Erosion(I,F):
  n=I.shape[0] #lines numbers
  m=I.shape[1] #columns numbers
  cst= (F.shape[0]-1)//2
  #create the new matrix of the smoothed image
  I_erode=np.ones([n,m])
  #Erosion without using inbuilt cv2 function for morphology
  for i in range(cst, n-cst):
    for j in range(cst,m-cst):
      temp= I[i-cst:i+cst+1, j-cst:j+cst+1]
      product= temp*F
      I_erode[i,j]= np.min(product)
      
  return I_erode

            
def Ouverture(I,F):
  
  I_Ouverture=Erosion(Dilatation(I,F),F)
  return I_Ouverture


def Fermeture(I,F):
  
  I_Fermeture=Dilatation(Erosion(I,F),F)
     
  return I_Fermeture

 
  
def Egaliastion_histogramme(img):

     y=np.array(img)

     # Calcule l'histogramme de l'image
     histo = np.zeros(256, int)      # prépare un vecteur de 256 zéros
     for i in range(0,img.size[1]):       # énumère les lignes
         for j in range(0,img.size[0]):   # énumère les colonnes
             histo[y[i,j]] = histo[y[i,j]] + 1

     
     # Calcule l'histogramme cumulé hc
     hc = np.zeros(256, int)         
     hc[0] = histo[0]
     for i in range(1,256):
         hc[i] = histo[i] + hc[i-1]


     # Normalise l'histogramme cumulé
     nbpixels = y.size
     hc =hc / nbpixels * 255


     for i in range(0,y.shape[0]):       
        for j in range(0,y.shape[1]):   
            y[i,j] =hc[y[i,j]]


     # Calcule l'histogramme de l'image apres egalisation 
     histo2 = np.zeros(256, int)      
     for i in range(0,img.size[1]):       
         for j in range(0,img.size[0]): 
             histo2[y[i,j]] = histo2[y[i,j]] + 1

     Img=Image.fromarray(y)
     return Img

def lissage_image(img):
     
     I=np.array(img)
     #/////////PART1 ***** REMPLISSAGE DE L'IMAGE ****** ///////
     I=Remplissage(I)
     #/////////***** FIN DU REMPLISSAGE DE L'IMAGE ****** ///////
     #/////////PART2 ***** APPICATION DU FILTRE MEAN ****** ///////
     filter_size=3
     temp = []
     indexer = filter_size // 2

     n=I.shape[0] #lines numbers
     m=I.shape[1] #columns numbers

     #create the new matrix of the smoothed image
     I_Lissage=np.ones([n,m])

     for i in range(1,len(I)-1):
       for j in range(1,len(I[0])-1):
          for z in range(filter_size):
             for k in range(filter_size):
               temp.append(I[i + z - indexer][j + k - indexer])

          temp.sort()
          I_Lissage[i][j] = temp[len(temp) // 2]
          temp = []     
     
     #/////////PART3 ***** TRIMMING IMAGE  ****** ///////
     I_Trim=Trim(I_Lissage)
     Img_Lissage=Image.fromarray(I_Trim)
     #/////////***** FIN DEU TRIMMING ****** ///////
     
     if Img_Lissage != 'RGB':
       Img_Lissage = Img_Lissage.convert('RGB')
    

     return Img_Lissage 

def Amelioration_contraste(img):
    y=np.array(img)

    Lmax=np.max(y)
    Lmin=np.min(y)
    #des paramètres a choisir
    Kmin=0
    Kmax=255

    for i in range(0,img.size[1]):       
       for j in range(0,img.size[0]):   
           y[i,j]=Kmin+ (((Kmax-Kmin)/(Lmax-Lmin))*(y[i,j]-Lmin))
        
    Img=Image.fromarray(y)
    return Img

def Operation_Morphologique(img):
    I=np.array(img)

    #/////////PART1 *****REMPLISSAGE DE L'IMAGE EN NOIR ET BLANC ****** ///////
    I=Remplissage(I)
    #/////////***** FIN DU REMPLISSAGE DE L'IMAGE ****** ///////
    #/////////PART2 *****TRANSFORMATION DE L'IMAGE EN NOIR ET BLANC ****** ///////
    I_convert=Conversion(I)  
    #/////////***** FIN DE LA TRANSFORMATION DE L'IMAGE EN NOIR ET BLANC ****** ///////
    #/////////PART3 ***** APPICATION DU FILTRE NON LINEAIRE ****** ///////
    #Creation du filtre
    F=np.ones([3,3])*255
    #Application du filtre pour lissage
    I_erosion=Erosion(I_convert,F)
    I_dilatation=Dilatation(I_convert,F)
    I_ouverture=Ouverture(I_convert,F)
    I_fetmeture=Fermeture(I_convert,F)
    #/////////***** FIN DE APPICATION DES OPERATION SUR L'IMAGE EN NOIR ET BLANC ****** ///////
    #/////////PART3 ***** TRIMMING IMAGE  ****** ///////
    I_trim=Trim(I_erosion)
    I_trim1=Trim(I_dilatation)
    I_trim2=Trim(I_ouverture)
    I_trim3=Trim(I_fetmeture)

    Img_erosion=Image.fromarray(I_trim)    
    Img_dialatation=Image.fromarray(I_trim1)
    Img_ouverture=Image.fromarray(I_trim2)    
    Img_fermeture=Image.fromarray(I_trim3)
    return Img_erosion,Img_dialatation,Img_ouverture,Img_fermeture

def Segmentation_avec_clusstering(img):
    #initialiser le nombre de clusters
    k = 4
    #Convertir l'image en RGB
    img = img.convert('RGB')
    img_width, img_height = img.size
    px = img.load()
    #Commencer le clustering
    result = startKmeans(k,img_width, img_height,px)
    #Cree la nouvelle image clusteriser
    img = Image.new('RGB', (img_width, img_height), "white")
    p = img.load()
    for x in range(img.size[0]):
	    for y in range(img.size[1]):
		    RGB_value = result[getMin(px[x, y], result)]
		    p[x, y] = RGB_value
    return img
     

def detecteur_discripteur_SIFT(img1):
   img1 = np.array(img1)
   #Transform image a une image au niveau gris
   img = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
   mypath="Casia v1 ImageTraiter"
   onlyfiles = [ f for f in listdir(mypath) if isfile(join(mypath,f)) ]
   images = np.empty(len(onlyfiles), dtype=object)
   for n in range(0, len(onlyfiles)):
     dist=0
     images[n] = cv2.imread( join(mypath,onlyfiles[n]) )
     #Transform image a une image au niveau gris
     images[n] = cv2.cvtColor(images[n], cv2.COLOR_BGR2GRAY)
     #Creé SIFT
     sift = cv2.SIFT_create()
     #Detection des points clés dans l'image
     keypoints_1, descriptors_1 = sift.detectAndCompute(img,None)
     keypoints_2, descriptors_2 = sift.detectAndCompute(images[n],None)
     #correspondance des points clés
     bf = cv2.BFMatcher(cv2.NORM_L1, crossCheck=True)
     matches = bf.match(descriptors_1,descriptors_2)
     matches = sorted(matches, key = lambda x:x.distance)
     #Dessiner des trait  de correspondance entre les points clé des deux images
     img3 = cv2.drawMatches(img, keypoints_1, images[n], keypoints_2, matches[:50], images[n], flags=2)
     dist=distance_eucledienne(keypoints_1[0], keypoints_2[0]) 
     #difinir un seuil 
     if dist<=10:
        break  
   if dist<=10:
       Label(l1, text="Personne accepter",fg="green",font=("courrier",25),bg="#677eaa").pack(side=LEFT)
   else:
       Label(l1, text="Personne rejeter",fg="red",font=("courrier",25),bg="#677eaa").pack(side=LEFT)
       
   img3=Image.fromarray(img3)
   return img3
 
def distance_eucledienne(kpt1, kpt2):
     #Cree numpy array avec les keypoint positions
     arr = np.array([kpt1.pt, kpt2.pt])
     #calculer la distance
     dist = np.linalg.norm(arr[0]-arr[1])
     return dist

   
# Main cree Frame
frame=Tk()
frame.title("Système biométrique d’identification d’individus par l’iris ")
frame.geometry("1000x600")
frame.minsize(600,500)
frame.config(background='#677eaa')

Titre= Label(frame,text="Bienvenue sur l'application",font=("courrier",40) ,bg="#677eaa",fg="white")
Titre.pack()

#frame l'introduction de l'image requete
l = LabelFrame(frame, text="Introduire une image d’iris :", padx=20, pady=20,bg="#677eaa",fg="white",font=("courrier",15))
l.pack(fill="both", side="top")
Label(l, text="Introduire votre image requête :",bg="#677eaa",fg="white",font=("courrier",10)).pack()
Button(l,text="Ouvrir l'image",font=("courrier",10),command=open_img,bg="white",fg="black").pack()
 
#frame la décision d’acceptation ou de rejet d’une personne donnée"

l1= LabelFrame(frame,text="La décision d’acceptation ou de rejet d’une personne donnée :", padx=10, pady=20,bg="#677eaa",fg="white",font=("courrier",15) )
l1.pack(fill="both",side="bottom")
Label(l1, text="  ",bg="#677eaa").pack(side=LEFT)# traitement


# la mise en correspondance 

l3= LabelFrame(frame, text="Mise en correspondance:                                                ", padx=10, pady=20,bg="#677eaa",fg="white",font=("courrier",15))
l3.pack(fill="both", side="right")
Label(l3,text=" ",font=("courrier",10) ,bg="#677eaa").pack()


#frame affichage de résultat de traitement de l'image

l2 = LabelFrame(frame, text="Résulat des étapes du traitement de l'image :", padx=5, pady=5,bg="#677eaa",fg="white",font=("courrier",15))

def myfunction(event):
    canvas.configure(scrollregion=canvas.bbox("all"),width=350,height=500)



myframe=Frame(l2,relief=GROOVE,width=50,height=200,bd=7)

myframe.pack(side="left")
canvas=Canvas(myframe)
frame=Frame(canvas)

myscrollbar=Scrollbar(myframe,orient="vertical",command=canvas.yview)
canvas.configure(yscrollcommand=myscrollbar.set)

myscrollbar.pack(side="right",fill="y")
canvas.pack(side="left")
canvas.create_window((0,0),window=frame,anchor='nw')
frame.bind("<Configure>",myfunction)

Label(l2,text=" ",font=("courrier",10) ,bg="#677eaa",).pack(side="left")# traitement
l2.pack(fill="both",side="left")

#afficher Frame
frame.mainloop()






